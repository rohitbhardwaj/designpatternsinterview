# Template Method

Keep an algorithm’s sequence fixed while subclasses fill selected steps.

**Category:** Behavioral

## Start here

- **3 minutes:** Read this page or Quick_Review.pdf.
- **10 minutes:** Answer Interview_QA.md aloud before revealing the answers.
- **15 minutes:** Follow Practice.md and run the Java exercise.
- **48 seconds:** Watch Pattern_Video.mp4; the clip is silent and captioned.
- **With AI:** Copy one prompt from AI_Prompts.txt, then verify the result.

## Picture it

A recipe fixes the order of preparation while letting a cook choose one ingredient.

## Use it when

Several subclasses share a stable algorithm sequence with a few deliberate variation points.

## Keep it simpler when

There are many interacting hooks, or runtime composition would fit better than inheritance.

## Contract

generate always fetches, renders, and saves in that order; subclasses customize rendering only.

## Nearby idea

Template Method varies selected inherited steps. Strategy varies behavior supplied as a collaborator.

## Interview checkpoint

**Question:** What prevents a subclass from replacing the entire required sequence?

**Answer:** Make the template method final when preserving its sequence is part of the design.

## Try it

Implement PdfReport.render while keeping generate unchanged and final.

## Evidence

Check the complete generated output and exact event sequence, rather than testing render alone.

## Trade-off

Too many hooks make the base-class algorithm difficult to understand.

## Scope

The Java exercise is a small, single-process teaching example. Its scenario can differ from the video to help you recognize the same idea in another setting.

[Open the complete visual guide](README.html) | [Interview questions](Interview_QA.md) | [Practice](Practice.md) | [Solution notes](Solution_Notes.md)
