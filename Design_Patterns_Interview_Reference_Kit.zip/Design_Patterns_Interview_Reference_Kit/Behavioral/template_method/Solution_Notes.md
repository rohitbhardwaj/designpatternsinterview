# Template Method - Solution Notes

## The change

Return a PDF representation of the fetched data. The base class controls the sequence.

## Why it works

generate always fetches, renders, and saves in that order; subclasses customize rendering only.

## How the checks expose mistakes

Check the complete generated output and exact event sequence, rather than testing render alone.

## What to say in an interview

I chose this design because several subclasses share a stable algorithm sequence with a few deliberate variation points. The trade-off is: Too many hooks make the base-class algorithm difficult to understand.

## Nearby alternative

Template Method varies selected inherited steps. Strategy varies behavior supplied as a collaborator.

## When to simplify

There are many interacting hooks, or runtime composition would fit better than inheritance.

Read the complete implementation in `java/solution/Demo.java`. Compare the TASK area with the starter and trace the exercise checks.
