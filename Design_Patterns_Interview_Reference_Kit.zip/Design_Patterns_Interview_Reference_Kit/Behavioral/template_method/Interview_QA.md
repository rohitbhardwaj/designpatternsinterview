# Template Method - Interview Questions and Answers

These are original practice questions aligned with skills in published employer guidance. They are not attributed to an actual company interview, endorsed by an employer, or a prediction of interview frequency. See INTERVIEW_GUIDANCE.md at the kit root.

Try each answer aloud in 60-90 seconds. Model answers are examples, not scripts to memorize.

## 1. Explain the idea in plain English, then connect it to code.

**Model answer:** Keep an algorithm’s sequence fixed while subclasses fill selected steps. A recipe fixes the order of preparation while letting a cook choose one ingredient. In this exercise: generate always fetches, renders, and saves in that order; subclasses customize rendering only. Return a PDF representation of the fetched data. The base class controls the sequence.

**What to demonstrate:** Explain the collaboration before naming classes.

## 2. What prevents a subclass from replacing the entire required sequence?

**Model answer:** Make the template method final when preserving its sequence is part of the design.

**What to demonstrate:** Give a concrete example that makes the distinction clear.

## 3. What nearby idea is easy to confuse with this one?

**Model answer:** Template Method varies selected inherited steps. Strategy varies behavior supplied as a collaborator.

**What to demonstrate:** Compare intent and behavior, not just similar-looking diagrams.

## 4. Change request: Implement PdfReport.render while keeping generate unchanged and final.

**Model answer:** Return a PDF representation of the fetched data. The base class controls the sequence.

**What to demonstrate:** Name the exact extension point and identify what remains stable.

## 5. Which tests would convince you that the change is correct?

**Model answer:** Check the complete generated output and exact event sequence, rather than testing render alone.

**What to demonstrate:** State inputs, expected outcomes, and the defect each test would expose.

## 6. What would you clarify before implementing this scenario?

**Model answer:** Ask which steps are fixed and which can vary. Here fetch and save are fixed; render is the extension point.

**What to demonstrate:** Resolve a consequential ambiguity before coding.

## 7. When would you keep the design simpler or choose another approach?

**Model answer:** There are many interacting hooks, or runtime composition would fit better than inheritance. Too many hooks make the base-class algorithm difficult to understand.

**What to demonstrate:** Explain the cost of the abstraction and the condition that justifies it.

## Self-check

Can you clarify the contract, draw the collaboration, identify the change point, write a test, and explain when a simpler approach wins? Use the original 10-point rubric in the root Interview_Approach.md.
