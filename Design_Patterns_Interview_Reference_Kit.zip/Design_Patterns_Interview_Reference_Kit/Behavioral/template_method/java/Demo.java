import java.util.*;

// Original small teaching example. Java 17+, no external libraries.
// Run: java Demo.java
// Exercise checks: java Demo.java --exercise
// Run each folder separately; every example intentionally uses the class name Demo.
public class Demo {
    static int checks;
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
    }
    static void throwsType(Class<? extends Throwable> type, Runnable action) {
        try { action.run(); }
        catch (Throwable error) {
            if (!type.isInstance(error)) throw new AssertionError("Expected " + type.getSimpleName() + ", got " + error, error);
            checks++; return;
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }
    abstract static class Report {
        final List<String> events = new ArrayList<>();
        final String generate() {
            events.add("fetch"); String data = "sales";
            events.add("render"); String output = render(data);
            events.add("save"); return output + ":saved";
        }
        abstract String render(String data);
    }
    static class CsvReport extends Report { String render(String data) { return "CSV:" + data; } }
    static class PdfReport extends Report { String render(String data) {
        throw new UnsupportedOperationException("Implement PDF render step");
    } }

    public static void main(String[] args) {
        check(new CsvReport().generate().equals("CSV:sales:saved"), "existing template execution");
        if (args.length > 0 && args[0].equals("--exercise")) {
            PdfReport pdf = new PdfReport();
            check(pdf.generate().equals("PDF:sales:saved"), "custom rendering");
            check(pdf.events.equals(List.of("fetch", "render", "save")), "required order");
        }
        System.out.println("PASS: Template Method (" + checks + " checks)");
    }
}
