# Iterator

Traverse a collection without exposing its representation.

**Category:** Behavioral

## Start here

- **3 minutes:** Read this page or Quick_Review.pdf.
- **10 minutes:** Answer Interview_QA.md aloud before revealing the answers.
- **15 minutes:** Follow Practice.md and run the Java exercise.
- **48 seconds:** Watch Pattern_Video.mp4; the clip is silent and captioned.
- **With AI:** Copy one prompt from AI_Prompts.txt, then verify the result.

## Picture it

A bookmark remembers your place without requiring you to reorganize the book.

## Use it when

Clients need traversal without knowing collection storage details.

## Keep it simpler when

A shared global cursor would force independent callers to interfere with each other.

## Contract

Each iterator starts independently, next advances once, and exhaustion throws NoSuchElementException.

## Nearby idea

Iterator owns traversal state. The collection owns the elements; each iterator normally has its own cursor.

## Interview checkpoint

**Question:** Should two independent iterators necessarily share a cursor?

**Answer:** No. Each iterator normally owns its traversal state.

## Try it

Implement Playlist.iterator with a fresh cursor on every call.

## Evidence

Interleave two iterators and verify both start at A. Test exhaustion and an empty playlist.

## Trade-off

Modification during iteration needs explicit, documented behavior.

## Scope

The Java exercise is a small, single-process teaching example. Its scenario can differ from the video to help you recognize the same idea in another setting.

[Open the complete visual guide](README.html) | [Interview questions](Interview_QA.md) | [Practice](Practice.md) | [Solution notes](Solution_Notes.md)
