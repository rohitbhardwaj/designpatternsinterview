import java.util.*;

// Original small teaching example. Java 17+, no external libraries.
// Run: java Demo.java
// Exercise checks: java Demo.java --exercise
// Run each folder separately; every example intentionally uses the class name Demo.
public class Demo {
    static int checks;
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
    }
    static void throwsType(Class<? extends Throwable> type, Runnable action) {
        try { action.run(); }
        catch (Throwable error) {
            if (!type.isInstance(error)) throw new AssertionError("Expected " + type.getSimpleName() + ", got " + error, error);
            checks++; return;
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }
    record Playlist(List<String> tracks) implements Iterable<String> {
        Playlist { tracks = List.copyOf(tracks); }
        public Iterator<String> iterator() {
            throw new UnsupportedOperationException("Implement iterator");
        }
    }

    public static void main(String[] args) {
        Playlist playlist = new Playlist(List.of("A", "B"));
        check(playlist.tracks().size() == 2, "collection contains tracks");
        if (args.length > 0 && args[0].equals("--exercise")) {
            Iterator<String> first = playlist.iterator(), second = playlist.iterator();
            check(first.next().equals("A") && second.next().equals("A"), "independent cursors");
            check(first.next().equals("B") && !first.hasNext(), "ordered traversal");
            throwsType(NoSuchElementException.class, first::next);
            Iterator<String> empty = new Playlist(List.of()).iterator();
            check(!empty.hasNext(), "empty collection");
            throwsType(NoSuchElementException.class, empty::next);
        }
        System.out.println("PASS: Iterator (" + checks + " checks)");
    }
}
