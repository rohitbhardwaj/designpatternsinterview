# Iterator - Interview Questions and Answers

These are original practice questions aligned with skills in published employer guidance. They are not attributed to an actual company interview, endorsed by an employer, or a prediction of interview frequency. See INTERVIEW_GUIDANCE.md at the kit root.

Try each answer aloud in 60-90 seconds. Model answers are examples, not scripts to memorize.

## 1. Explain the idea in plain English, then connect it to code.

**Model answer:** Traverse a collection without exposing its representation. A bookmark remembers your place without requiring you to reorganize the book. In this exercise: Each iterator starts independently, next advances once, and exhaustion throws NoSuchElementException. Return a new Iterator with its own index. Check hasNext before reading and increment after each successful next.

**What to demonstrate:** Explain the collaboration before naming classes.

## 2. Should two independent iterators necessarily share a cursor?

**Model answer:** No. Each iterator normally owns its traversal state.

**What to demonstrate:** Give a concrete example that makes the distinction clear.

## 3. What nearby idea is easy to confuse with this one?

**Model answer:** Iterator owns traversal state. The collection owns the elements; each iterator normally has its own cursor.

**What to demonstrate:** Compare intent and behavior, not just similar-looking diagrams.

## 4. Change request: Implement Playlist.iterator with a fresh cursor on every call.

**Model answer:** Return a new Iterator with its own index. Check hasNext before reading and increment after each successful next.

**What to demonstrate:** Name the exact extension point and identify what remains stable.

## 5. Which tests would convince you that the change is correct?

**Model answer:** Interleave two iterators and verify both start at A. Test exhaustion and an empty playlist.

**What to demonstrate:** State inputs, expected outcomes, and the defect each test would expose.

## 6. What would you clarify before implementing this scenario?

**Model answer:** Ask about ordering and mutation. The playlist makes an immutable snapshot at construction and traverses in list order.

**What to demonstrate:** Resolve a consequential ambiguity before coding.

## 7. When would you keep the design simpler or choose another approach?

**Model answer:** A shared global cursor would force independent callers to interfere with each other. Modification during iteration needs explicit, documented behavior.

**What to demonstrate:** Explain the cost of the abstraction and the condition that justifies it.

## Self-check

Can you clarify the contract, draw the collaboration, identify the change point, write a test, and explain when a simpler approach wins? Use the original 10-point rubric in the root Interview_Approach.md.
