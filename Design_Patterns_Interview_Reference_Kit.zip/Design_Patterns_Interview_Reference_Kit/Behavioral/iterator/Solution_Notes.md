# Iterator - Solution Notes

## The change

Return a new Iterator with its own index. Check hasNext before reading and increment after each successful next.

## Why it works

Each iterator starts independently, next advances once, and exhaustion throws NoSuchElementException.

## How the checks expose mistakes

Interleave two iterators and verify both start at A. Test exhaustion and an empty playlist.

## What to say in an interview

I chose this design because clients need traversal without knowing collection storage details. The trade-off is: Modification during iteration needs explicit, documented behavior.

## Nearby alternative

Iterator owns traversal state. The collection owns the elements; each iterator normally has its own cursor.

## When to simplify

A shared global cursor would force independent callers to interfere with each other.

Read the complete implementation in `java/solution/Demo.java`. Compare the TASK area with the starter and trace the exercise checks.
