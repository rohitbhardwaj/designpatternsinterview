# Observer - Interview Questions and Answers

These are original practice questions aligned with skills in published employer guidance. They are not attributed to an actual company interview, endorsed by an employer, or a prediction of interview frequency. See INTERVIEW_GUIDANCE.md at the kit root.

Try each answer aloud in 60-90 seconds. Model answers are examples, not scripts to memorize.

## 1. Explain the idea in plain English, then connect it to code.

**Model answer:** Notify registered dependents when a subject changes. Subscribers register for a newsletter; the publisher does not need to know how each reader uses it. In this exercise: Registered observers are called once per publish; an unsubscribed observer receives no future events. Remove that observer instance from the subscription set. Publish over a snapshot so subscription changes do not corrupt iteration.

**What to demonstrate:** Explain the collaboration before naming classes.

## 2. Does Observer guarantee messages survive a process crash?

**Model answer:** No. Durability requires a separate messaging or persistence design.

**What to demonstrate:** Give a concrete example that makes the distinction clear.

## 3. What nearby idea is easy to confuse with this one?

**Model answer:** Observer describes subscription and notification. A durable message broker adds different delivery and persistence guarantees.

**What to demonstrate:** Compare intent and behavior, not just similar-looking diagrams.

## 4. Change request: Implement unsubscribe and preserve delivery to remaining observers.

**Model answer:** Remove that observer instance from the subscription set. Publish over a snapshot so subscription changes do not corrupt iteration.

**What to demonstrate:** Name the exact extension point and identify what remains stable.

## 5. Which tests would convince you that the change is correct?

**Model answer:** Publish once to two listeners, unsubscribe one, publish again, and compare each listener’s event history.

**What to demonstrate:** State inputs, expected outcomes, and the defect each test would expose.

## 6. What would you clarify before implementing this scenario?

**Model answer:** Ask about ordering, exceptions, and lifetime. Here delivery is synchronous, insertion-ordered, and fail-fast on subscriber exceptions.

**What to demonstrate:** Resolve a consequential ambiguity before coding.

## 7. When would you keep the design simpler or choose another approach?

**Model answer:** You need durable cross-process delivery but have only implemented in-memory callbacks. Slow observers, retained subscriptions, and recursive updates can cause trouble.

**What to demonstrate:** Explain the cost of the abstraction and the condition that justifies it.

## Self-check

Can you clarify the contract, draw the collaboration, identify the change point, write a test, and explain when a simpler approach wins? Use the original 10-point rubric in the root Interview_Approach.md.
