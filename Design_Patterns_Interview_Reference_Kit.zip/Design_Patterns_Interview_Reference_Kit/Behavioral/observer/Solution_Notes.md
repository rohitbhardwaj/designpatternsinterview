# Observer - Solution Notes

## The change

Remove that observer instance from the subscription set. Publish over a snapshot so subscription changes do not corrupt iteration.

## Why it works

Registered observers are called once per publish; an unsubscribed observer receives no future events.

## How the checks expose mistakes

Publish once to two listeners, unsubscribe one, publish again, and compare each listener’s event history.

## What to say in an interview

I chose this design because a subject needs to notify a changing set of interested dependents. The trade-off is: Slow observers, retained subscriptions, and recursive updates can cause trouble.

## Nearby alternative

Observer describes subscription and notification. A durable message broker adds different delivery and persistence guarantees.

## When to simplify

You need durable cross-process delivery but have only implemented in-memory callbacks.

Read the complete implementation in `java/solution/Demo.java`. Compare the TASK area with the starter and trace the exercise checks.
