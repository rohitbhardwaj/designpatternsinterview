import java.util.*;

// Original small teaching example. Java 17+, no external libraries.
// Run: java Demo.java
// Exercise checks: java Demo.java --exercise
// Run each folder separately; every example intentionally uses the class name Demo.
public class Demo {
    static int checks;
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
    }
    static void throwsType(Class<? extends Throwable> type, Runnable action) {
        try { action.run(); }
        catch (Throwable error) {
            if (!type.isInstance(error)) throw new AssertionError("Expected " + type.getSimpleName() + ", got " + error, error);
            checks++; return;
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }
    interface Listener { void onEvent(String event); }
    static class Subject {
        final Set<Listener> listeners = new LinkedHashSet<>();
        void subscribe(Listener listener) { listeners.add(listener); }
        void unsubscribe(Listener listener) {
            // TASK: remove the listener.
        }
        void publish(String event) {
            for (Listener listener : new ArrayList<>(listeners)) listener.onEvent(event);
        }
    }

    public static void main(String[] args) {
        Subject subject = new Subject(); List<String> a = new ArrayList<>(), b = new ArrayList<>();
        Listener first = a::add, second = b::add;
        subject.subscribe(first); subject.subscribe(second); subject.publish("PAID");
        check(a.equals(List.of("PAID")) && b.equals(List.of("PAID")), "fan-out");
        if (args.length > 0 && args[0].equals("--exercise")) {
            subject.unsubscribe(first); subject.publish("SHIPPED");
            check(a.equals(List.of("PAID")), "unsubscribed listener stays unchanged");
            check(b.equals(List.of("PAID", "SHIPPED")), "remaining listener notified");
            subject.unsubscribe(first); // Removing an absent listener is harmless.
        }
        System.out.println("PASS: Observer (" + checks + " checks)");
    }
}
