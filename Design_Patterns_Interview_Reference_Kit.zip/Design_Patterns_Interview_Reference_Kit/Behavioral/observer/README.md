# Observer

Notify registered dependents when a subject changes.

**Category:** Behavioral

## Start here

- **3 minutes:** Read this page or Quick_Review.pdf.
- **10 minutes:** Answer Interview_QA.md aloud before revealing the answers.
- **15 minutes:** Follow Practice.md and run the Java exercise.
- **48 seconds:** Watch Pattern_Video.mp4; the clip is silent and captioned.
- **With AI:** Copy one prompt from AI_Prompts.txt, then verify the result.

## Picture it

Subscribers register for a newsletter; the publisher does not need to know how each reader uses it.

## Use it when

A subject needs to notify a changing set of interested dependents.

## Keep it simpler when

You need durable cross-process delivery but have only implemented in-memory callbacks.

## Contract

Registered observers are called once per publish; an unsubscribed observer receives no future events.

## Nearby idea

Observer describes subscription and notification. A durable message broker adds different delivery and persistence guarantees.

## Interview checkpoint

**Question:** Does Observer guarantee messages survive a process crash?

**Answer:** No. Durability requires a separate messaging or persistence design.

## Try it

Implement unsubscribe and preserve delivery to remaining observers.

## Evidence

Publish once to two listeners, unsubscribe one, publish again, and compare each listener’s event history.

## Trade-off

Slow observers, retained subscriptions, and recursive updates can cause trouble.

## Scope

The Java exercise is a small, single-process teaching example. Its scenario can differ from the video to help you recognize the same idea in another setting.

[Open the complete visual guide](README.html) | [Interview questions](Interview_QA.md) | [Practice](Practice.md) | [Solution notes](Solution_Notes.md)
