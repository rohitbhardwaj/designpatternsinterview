# Command - Solution Notes

## The change

Restore the captured Boolean instead of always turning the lamp off. Reject undo when there is no pending execution.

## Why it works

Undo restores the prior lamp state, even when the lamp was already on before execution.

## How the checks expose mistakes

Exercise both initially-off and initially-on lamps, plus undo-before-execute.

## What to say in an interview

I chose this design because an action needs to be stored, scheduled, composed, or paired with explicit undo behavior. The trade-off is: Retrying a command can repeat a side effect unless execution is idempotent.

## Nearby alternative

Command captures an action. Memento captures restorable state; commands can use mementos for undo.

## When to simplify

The operation is a simple direct call with no need to represent the request as data or an object.

Read the complete implementation in `java/solution/Demo.java`. Compare the TASK area with the starter and trace the exercise checks.
