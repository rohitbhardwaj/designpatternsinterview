# Command

Represent an action as an object that can be stored or scheduled.

**Category:** Behavioral

## Start here

- **3 minutes:** Read this page or Quick_Review.pdf.
- **10 minutes:** Answer Interview_QA.md aloud before revealing the answers.
- **15 minutes:** Follow Practice.md and run the Java exercise.
- **48 seconds:** Watch Pattern_Video.mp4; the clip is silent and captioned.
- **With AI:** Copy one prompt from AI_Prompts.txt, then verify the result.

## Picture it

A written work order can be queued, executed, and recorded independently of the worker.

## Use it when

An action needs to be stored, scheduled, composed, or paired with explicit undo behavior.

## Keep it simpler when

The operation is a simple direct call with no need to represent the request as data or an object.

## Contract

Undo restores the prior lamp state, even when the lamp was already on before execution.

## Nearby idea

Command captures an action. Memento captures restorable state; commands can use mementos for undo.

## Interview checkpoint

**Question:** Can every command safely implement undo()?

**Answer:** No. Some effects need compensation, and some cannot be undone.

## Try it

Implement LightOn.undo using the state captured by execute, then clear that saved state.

## Evidence

Exercise both initially-off and initially-on lamps, plus undo-before-execute.

## Trade-off

Retrying a command can repeat a side effect unless execution is idempotent.

## Scope

The Java exercise is a small, single-process teaching example. Its scenario can differ from the video to help you recognize the same idea in another setting.

[Open the complete visual guide](README.html) | [Interview questions](Interview_QA.md) | [Practice](Practice.md) | [Solution notes](Solution_Notes.md)
