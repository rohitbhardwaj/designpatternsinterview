# Command - Interview Questions and Answers

These are original practice questions aligned with skills in published employer guidance. They are not attributed to an actual company interview, endorsed by an employer, or a prediction of interview frequency. See INTERVIEW_GUIDANCE.md at the kit root.

Try each answer aloud in 60-90 seconds. Model answers are examples, not scripts to memorize.

## 1. Explain the idea in plain English, then connect it to code.

**Model answer:** Represent an action as an object that can be stored or scheduled. A written work order can be queued, executed, and recorded independently of the worker. In this exercise: Undo restores the prior lamp state, even when the lamp was already on before execution. Restore the captured Boolean instead of always turning the lamp off. Reject undo when there is no pending execution.

**What to demonstrate:** Explain the collaboration before naming classes.

## 2. Can every command safely implement undo()?

**Model answer:** No. Some effects need compensation, and some cannot be undone.

**What to demonstrate:** Give a concrete example that makes the distinction clear.

## 3. What nearby idea is easy to confuse with this one?

**Model answer:** Command captures an action. Memento captures restorable state; commands can use mementos for undo.

**What to demonstrate:** Compare intent and behavior, not just similar-looking diagrams.

## 4. Change request: Implement LightOn.undo using the state captured by execute, then clear that saved state.

**Model answer:** Restore the captured Boolean instead of always turning the lamp off. Reject undo when there is no pending execution.

**What to demonstrate:** Name the exact extension point and identify what remains stable.

## 5. Which tests would convince you that the change is correct?

**Model answer:** Exercise both initially-off and initially-on lamps, plus undo-before-execute.

**What to demonstrate:** State inputs, expected outcomes, and the defect each test would expose.

## 6. What would you clarify before implementing this scenario?

**Model answer:** Ask whether effects are reversible and whether commands are reusable. Here a command supports one outstanding execution followed by undo.

**What to demonstrate:** Resolve a consequential ambiguity before coding.

## 7. When would you keep the design simpler or choose another approach?

**Model answer:** The operation is a simple direct call with no need to represent the request as data or an object. Retrying a command can repeat a side effect unless execution is idempotent.

**What to demonstrate:** Explain the cost of the abstraction and the condition that justifies it.

## Self-check

Can you clarify the contract, draw the collaboration, identify the change point, write a test, and explain when a simpler approach wins? Use the original 10-point rubric in the root Interview_Approach.md.
