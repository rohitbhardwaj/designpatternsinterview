import java.util.*;

// Original small teaching example. Java 17+, no external libraries.
// Run: java Demo.java
// Exercise checks: java Demo.java --exercise
// Run each folder separately; every example intentionally uses the class name Demo.
public class Demo {
    static int checks;
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
    }
    static void throwsType(Class<? extends Throwable> type, Runnable action) {
        try { action.run(); }
        catch (Throwable error) {
            if (!type.isInstance(error)) throw new AssertionError("Expected " + type.getSimpleName() + ", got " + error, error);
            checks++; return;
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }
    static class Lamp { boolean on; }
    static class LightOn {
        final Lamp lamp; Boolean before;
        LightOn(Lamp lamp) { this.lamp = lamp; }
        void execute() {
            if (before != null) throw new IllegalStateException("already executed");
            before = lamp.on; lamp.on = true;
        }
        void undo() {
            if (before == null) throw new IllegalStateException("nothing to undo");
                    lamp.on = before; before = null;
        }
    }

    public static void main(String[] args) {
        Lamp lamp = new Lamp(); LightOn command = new LightOn(lamp);
        command.execute(); check(lamp.on, "execute turned lamp on");
        if (args.length > 0 && args[0].equals("--exercise")) {
            command.undo(); check(!lamp.on, "restore initially-off state");
            lamp.on = true; LightOn alreadyOn = new LightOn(lamp);
            alreadyOn.execute(); alreadyOn.undo(); check(lamp.on, "restore initially-on state");
            throwsType(IllegalStateException.class, () -> new LightOn(lamp).undo());
        }
        System.out.println("PASS: Command (" + checks + " checks)");
    }
}
