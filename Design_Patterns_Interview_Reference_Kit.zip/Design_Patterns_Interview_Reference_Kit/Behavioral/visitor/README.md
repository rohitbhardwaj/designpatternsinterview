# Visitor

Add operations across a stable set of element types.

**Category:** Behavioral

## Start here

- **3 minutes:** Read this page or Quick_Review.pdf.
- **10 minutes:** Answer Interview_QA.md aloud before revealing the answers.
- **15 minutes:** Follow Practice.md and run the Java exercise.
- **48 seconds:** Watch Pattern_Video.mp4; the clip is silent and captioned.
- **With AI:** Copy one prompt from AI_Prompts.txt, then verify the result.

## Picture it

Different specialists inspect the same building: an electrician and a safety inspector perform different operations on its fixed parts.

## Use it when

The element types are stable but new operations across those types are frequent.

## Keep it simpler when

New element types appear constantly and every visitor would require repeated updates.

## Contract

Each element dispatches to the visitor method for its concrete type, without instanceof checks in the visitor.

## Nearby idea

Visitor favors adding operations. Adding an element type changes the visitor contract; a simple method may be preferable for one stable operation.

## Interview checkpoint

**Question:** Which change is expensive in the classic Visitor design?

**Answer:** Adding a new element type because visitor contracts and implementations must handle it.

## Try it

Implement an AuditVisitor for existing Text and Image elements without changing those elements.

## Evidence

Visit both element types and check different results. Testing only Text can hide a missing Image implementation.

## Trade-off

Visitors may need access to element details and can weaken encapsulation.

## Scope

The Java exercise is a small, single-process teaching example. Its scenario can differ from the video to help you recognize the same idea in another setting.

[Open the complete visual guide](README.html) | [Interview questions](Interview_QA.md) | [Practice](Practice.md) | [Solution notes](Solution_Notes.md)
