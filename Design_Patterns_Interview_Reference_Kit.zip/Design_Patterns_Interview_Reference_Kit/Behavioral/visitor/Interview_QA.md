# Visitor - Interview Questions and Answers

These are original practice questions aligned with skills in published employer guidance. They are not attributed to an actual company interview, endorsed by an employer, or a prediction of interview frequency. See INTERVIEW_GUIDANCE.md at the kit root.

Try each answer aloud in 60-90 seconds. Model answers are examples, not scripts to memorize.

## 1. Explain the idea in plain English, then connect it to code.

**Model answer:** Add operations across a stable set of element types. Different specialists inspect the same building: an electrician and a safety inspector perform different operations on its fixed parts. In this exercise: Each element dispatches to the visitor method for its concrete type, without instanceof checks in the visitor. Add visitText and visitImage implementations in the new visitor. Each element already selects its correct visit method through accept.

**What to demonstrate:** Explain the collaboration before naming classes.

## 2. Which change is expensive in the classic Visitor design?

**Model answer:** Adding a new element type because visitor contracts and implementations must handle it.

**What to demonstrate:** Give a concrete example that makes the distinction clear.

## 3. What nearby idea is easy to confuse with this one?

**Model answer:** Visitor favors adding operations. Adding an element type changes the visitor contract; a simple method may be preferable for one stable operation.

**What to demonstrate:** Compare intent and behavior, not just similar-looking diagrams.

## 4. Change request: Implement an AuditVisitor for existing Text and Image elements without changing those elements.

**Model answer:** Add visitText and visitImage implementations in the new visitor. Each element already selects its correct visit method through accept.

**What to demonstrate:** Name the exact extension point and identify what remains stable.

## 5. Which tests would convince you that the change is correct?

**Model answer:** Visit both element types and check different results. Testing only Text can hide a missing Image implementation.

**What to demonstrate:** State inputs, expected outcomes, and the defect each test would expose.

## 6. What would you clarify before implementing this scenario?

**Model answer:** Ask whether operations or element types change more often. This exercise adds operations to a stable two-type element family.

**What to demonstrate:** Resolve a consequential ambiguity before coding.

## 7. When would you keep the design simpler or choose another approach?

**Model answer:** New element types appear constantly and every visitor would require repeated updates. Visitors may need access to element details and can weaken encapsulation.

**What to demonstrate:** Explain the cost of the abstraction and the condition that justifies it.

## Self-check

Can you clarify the contract, draw the collaboration, identify the change point, write a test, and explain when a simpler approach wins? Use the original 10-point rubric in the root Interview_Approach.md.
