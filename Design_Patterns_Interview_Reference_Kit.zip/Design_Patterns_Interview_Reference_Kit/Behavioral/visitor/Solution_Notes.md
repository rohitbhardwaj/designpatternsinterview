# Visitor - Solution Notes

## The change

Add visitText and visitImage implementations in the new visitor. Each element already selects its correct visit method through accept.

## Why it works

Each element dispatches to the visitor method for its concrete type, without instanceof checks in the visitor.

## How the checks expose mistakes

Visit both element types and check different results. Testing only Text can hide a missing Image implementation.

## What to say in an interview

I chose this design because the element types are stable but new operations across those types are frequent. The trade-off is: Visitors may need access to element details and can weaken encapsulation.

## Nearby alternative

Visitor favors adding operations. Adding an element type changes the visitor contract; a simple method may be preferable for one stable operation.

## When to simplify

New element types appear constantly and every visitor would require repeated updates.

Read the complete implementation in `java/solution/Demo.java`. Compare the TASK area with the starter and trace the exercise checks.
