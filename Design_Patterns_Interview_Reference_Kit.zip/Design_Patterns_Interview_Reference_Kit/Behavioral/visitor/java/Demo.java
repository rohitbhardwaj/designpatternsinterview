import java.util.*;

// Original small teaching example. Java 17+, no external libraries.
// Run: java Demo.java
// Exercise checks: java Demo.java --exercise
// Run each folder separately; every example intentionally uses the class name Demo.
public class Demo {
    static int checks;
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
    }
    static void throwsType(Class<? extends Throwable> type, Runnable action) {
        try { action.run(); }
        catch (Throwable error) {
            if (!type.isInstance(error)) throw new AssertionError("Expected " + type.getSimpleName() + ", got " + error, error);
            checks++; return;
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }
    interface Visitor { String visitText(Text text); String visitImage(Image image); }
    interface Element { String accept(Visitor visitor); }
    record Text(String value) implements Element { public String accept(Visitor v) { return v.visitText(this); } }
    record Image(String name) implements Element { public String accept(Visitor v) { return v.visitImage(this); } }
    static class ExportVisitor implements Visitor {
        public String visitText(Text text) { return "text:" + text.value(); }
        public String visitImage(Image image) { return "image:" + image.name(); }
    }
    static Visitor auditVisitor() {
        throw new UnsupportedOperationException("Implement AuditVisitor");
    }

    public static void main(String[] args) {
        check(new Text("Hi").accept(new ExportVisitor()).equals("text:Hi"), "existing operation");
        if (args.length > 0 && args[0].equals("--exercise")) {
            Visitor audit = auditVisitor();
            check(new Text("Hello").accept(audit).equals("characters:5"), "text dispatch");
            check(new Image("logo.png").accept(audit).equals("check-image:logo.png"), "image dispatch");
        }
        System.out.println("PASS: Visitor (" + checks + " checks)");
    }
}
