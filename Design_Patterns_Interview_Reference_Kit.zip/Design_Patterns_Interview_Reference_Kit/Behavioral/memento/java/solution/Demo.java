import java.util.*;

// Original small teaching example. Java 17+, no external libraries.
// Run: java Demo.java
// Exercise checks: java Demo.java --exercise
// Run each folder separately; every example intentionally uses the class name Demo.
public class Demo {
    static int checks;
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
    }
    static void throwsType(Class<? extends Throwable> type, Runnable action) {
        try { action.run(); }
        catch (Throwable error) {
            if (!type.isInstance(error)) throw new AssertionError("Expected " + type.getSimpleName() + ", got " + error, error);
            checks++; return;
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }
    static class Editor {
        private String text;
        Editor(String text) { this.text = text; }
        String text() { return text; }
        void edit(String value) { text = value; }
        static final class Snapshot {
            private final String text;
            private Snapshot(String text) { this.text = text; }
        }
        Snapshot save() { return new Snapshot(text); }
        void restore(Snapshot snapshot) {
            text = snapshot.text;
        }
    }

    public static void main(String[] args) {
        Editor editor = new Editor("Hello");
        Editor.Snapshot saved = editor.save();
        editor.edit("Goodbye"); check(editor.text().equals("Goodbye"), "edit operation");
        if (args.length > 0 && args[0].equals("--exercise")) {
            editor.restore(saved); check(editor.text().equals("Hello"), "restore prior state");
            editor.edit("Another edit"); editor.restore(saved);
            check(editor.text().equals("Hello"), "snapshot remains stable");
        }
        System.out.println("PASS: Memento (" + checks + " checks)");
    }
}
