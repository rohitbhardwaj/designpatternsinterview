# Memento - Solution Notes

## The change

Let the editor interpret its own snapshot. The history stores the snapshot without reading its private fields.

## Why it works

A snapshot retains the editor text from save time; later edits do not alter it.

## How the checks expose mistakes

Save Hello, edit to Goodbye, restore, and repeat after another edit. The earlier snapshot must still contain Hello.

## What to say in an interview

I chose this design because an originator must save and restore state while a caretaker stores snapshots opaquely. The trade-off is: Large snapshots consume memory and may retain sensitive information.

## Nearby alternative

Memento stores state. Command stores an action; combining them can support undo without exposing internals to history.

## When to simplify

Snapshots are huge, retain sensitive information unnecessarily, or cannot represent external side effects.

Read the complete implementation in `java/solution/Demo.java`. Compare the TASK area with the starter and trace the exercise checks.
