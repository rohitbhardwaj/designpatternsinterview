# Memento - Interview Questions and Answers

These are original practice questions aligned with skills in published employer guidance. They are not attributed to an actual company interview, endorsed by an employer, or a prediction of interview frequency. See INTERVIEW_GUIDANCE.md at the kit root.

Try each answer aloud in 60-90 seconds. Model answers are examples, not scripts to memorize.

## 1. Explain the idea in plain English, then connect it to code.

**Model answer:** Capture restorable state while preserving encapsulation. A saved game lets you return to an earlier state without the save menu understanding the game’s internals. In this exercise: A snapshot retains the editor text from save time; later edits do not alter it. Let the editor interpret its own snapshot. The history stores the snapshot without reading its private fields.

**What to demonstrate:** Explain the collaboration before naming classes.

## 2. Who should interpret the contents of the memento?

**Model answer:** The originator that created it, rather than the caretaker.

**What to demonstrate:** Give a concrete example that makes the distinction clear.

## 3. What nearby idea is easy to confuse with this one?

**Model answer:** Memento stores state. Command stores an action; combining them can support undo without exposing internals to history.

**What to demonstrate:** Compare intent and behavior, not just similar-looking diagrams.

## 4. Change request: Implement Editor.restore using a snapshot created by Editor.save.

**Model answer:** Let the editor interpret its own snapshot. The history stores the snapshot without reading its private fields.

**What to demonstrate:** Name the exact extension point and identify what remains stable.

## 5. Which tests would convince you that the change is correct?

**Model answer:** Save Hello, edit to Goodbye, restore, and repeat after another edit. The earlier snapshot must still contain Hello.

**What to demonstrate:** State inputs, expected outcomes, and the defect each test would expose.

## 6. What would you clarify before implementing this scenario?

**Model answer:** Ask which state belongs in the snapshot and whether snapshots are reusable. Here immutable text is the entire state and snapshots can be reused.

**What to demonstrate:** Resolve a consequential ambiguity before coding.

## 7. When would you keep the design simpler or choose another approach?

**Model answer:** Snapshots are huge, retain sensitive information unnecessarily, or cannot represent external side effects. Large snapshots consume memory and may retain sensitive information.

**What to demonstrate:** Explain the cost of the abstraction and the condition that justifies it.

## Self-check

Can you clarify the contract, draw the collaboration, identify the change point, write a test, and explain when a simpler approach wins? Use the original 10-point rubric in the root Interview_Approach.md.
