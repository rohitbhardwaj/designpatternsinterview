# Memento

Capture restorable state while preserving encapsulation.

**Category:** Behavioral

## Start here

- **3 minutes:** Read this page or Quick_Review.pdf.
- **10 minutes:** Answer Interview_QA.md aloud before revealing the answers.
- **15 minutes:** Follow Practice.md and run the Java exercise.
- **48 seconds:** Watch Pattern_Video.mp4; the clip is silent and captioned.
- **With AI:** Copy one prompt from AI_Prompts.txt, then verify the result.

## Picture it

A saved game lets you return to an earlier state without the save menu understanding the game’s internals.

## Use it when

An originator must save and restore state while a caretaker stores snapshots opaquely.

## Keep it simpler when

Snapshots are huge, retain sensitive information unnecessarily, or cannot represent external side effects.

## Contract

A snapshot retains the editor text from save time; later edits do not alter it.

## Nearby idea

Memento stores state. Command stores an action; combining them can support undo without exposing internals to history.

## Interview checkpoint

**Question:** Who should interpret the contents of the memento?

**Answer:** The originator that created it, rather than the caretaker.

## Try it

Implement Editor.restore using a snapshot created by Editor.save.

## Evidence

Save Hello, edit to Goodbye, restore, and repeat after another edit. The earlier snapshot must still contain Hello.

## Trade-off

Large snapshots consume memory and may retain sensitive information.

## Scope

The Java exercise is a small, single-process teaching example. Its scenario can differ from the video to help you recognize the same idea in another setting.

[Open the complete visual guide](README.html) | [Interview questions](Interview_QA.md) | [Practice](Practice.md) | [Solution notes](Solution_Notes.md)
