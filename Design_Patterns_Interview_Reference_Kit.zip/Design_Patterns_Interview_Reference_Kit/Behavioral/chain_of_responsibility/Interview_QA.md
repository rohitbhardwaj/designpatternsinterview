# Chain of Responsibility - Interview Questions and Answers

These are original practice questions aligned with skills in published employer guidance. They are not attributed to an actual company interview, endorsed by an employer, or a prediction of interview frequency. See INTERVIEW_GUIDANCE.md at the kit root.

Try each answer aloud in 60-90 seconds. Model answers are examples, not scripts to memorize.

## 1. Explain the idea in plain English, then connect it to code.

**Model answer:** Pass a request until an eligible handler deals with it. A support request moves from agent to manager until someone has the authority to handle it. In this exercise: A refund is handled once by the first eligible handler; an unhandled request fails explicitly. Set the manager as the next handler. Preserve the early return when the current handler accepts the request.

**What to demonstrate:** Explain the collaboration before naming classes.

## 2. After one handler approves this refund, should the next handler run?

**Model answer:** No in this example. The first eligible handler completes the request.

**What to demonstrate:** Give a concrete example that makes the distinction clear.

## 3. What nearby idea is easy to confuse with this one?

**Model answer:** This chain stops at the first eligible handler. Some pipelines run all handlers; state which behavior the design promises.

**What to demonstrate:** Compare intent and behavior, not just similar-looking diagrams.

## 4. Change request: Connect agent and manager so the agent handles up to 100 and the manager up to 500.

**Model answer:** Set the manager as the next handler. Preserve the early return when the current handler accepts the request.

**What to demonstrate:** Name the exact extension point and identify what remains stable.

## 5. Which tests would convince you that the change is correct?

**Model answer:** Check 100 goes to Agent, 101 and 500 go to Manager, and 501 is unhandled.

**What to demonstrate:** State inputs, expected outcomes, and the defect each test would expose.

## 6. What would you clarify before implementing this scenario?

**Model answer:** Ask whether approval limits are inclusive and whether the chain stops. Both are explicit here: inclusive limits and first handler wins.

**What to demonstrate:** Resolve a consequential ambiguity before coding.

## 7. When would you keep the design simpler or choose another approach?

**Model answer:** All steps must always run in a fixed algorithm; a simple explicit sequence may communicate that better. Order changes can silently alter which handler wins.

**What to demonstrate:** Explain the cost of the abstraction and the condition that justifies it.

## Self-check

Can you clarify the contract, draw the collaboration, identify the change point, write a test, and explain when a simpler approach wins? Use the original 10-point rubric in the root Interview_Approach.md.
