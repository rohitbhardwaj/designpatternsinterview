# Chain of Responsibility

Pass a request until an eligible handler deals with it.

**Category:** Behavioral

## Start here

- **3 minutes:** Read this page or Quick_Review.pdf.
- **10 minutes:** Answer Interview_QA.md aloud before revealing the answers.
- **15 minutes:** Follow Practice.md and run the Java exercise.
- **48 seconds:** Watch Pattern_Video.mp4; the clip is silent and captioned.
- **With AI:** Copy one prompt from AI_Prompts.txt, then verify the result.

## Picture it

A support request moves from agent to manager until someone has the authority to handle it.

## Use it when

Several ordered handlers may take responsibility for a request.

## Keep it simpler when

All steps must always run in a fixed algorithm; a simple explicit sequence may communicate that better.

## Contract

A refund is handled once by the first eligible handler; an unhandled request fails explicitly.

## Nearby idea

This chain stops at the first eligible handler. Some pipelines run all handlers; state which behavior the design promises.

## Interview checkpoint

**Question:** After one handler approves this refund, should the next handler run?

**Answer:** No in this example. The first eligible handler completes the request.

## Try it

Connect agent and manager so the agent handles up to 100 and the manager up to 500.

## Evidence

Check 100 goes to Agent, 101 and 500 go to Manager, and 501 is unhandled.

## Trade-off

Order changes can silently alter which handler wins.

## Scope

The Java exercise is a small, single-process teaching example. Its scenario can differ from the video to help you recognize the same idea in another setting.

[Open the complete visual guide](README.html) | [Interview questions](Interview_QA.md) | [Practice](Practice.md) | [Solution notes](Solution_Notes.md)
