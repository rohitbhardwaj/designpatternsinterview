# Chain of Responsibility - Solution Notes

## The change

Set the manager as the next handler. Preserve the early return when the current handler accepts the request.

## Why it works

A refund is handled once by the first eligible handler; an unhandled request fails explicitly.

## How the checks expose mistakes

Check 100 goes to Agent, 101 and 500 go to Manager, and 501 is unhandled.

## What to say in an interview

I chose this design because several ordered handlers may take responsibility for a request. The trade-off is: Order changes can silently alter which handler wins.

## Nearby alternative

This chain stops at the first eligible handler. Some pipelines run all handlers; state which behavior the design promises.

## When to simplify

All steps must always run in a fixed algorithm; a simple explicit sequence may communicate that better.

Read the complete implementation in `java/solution/Demo.java`. Compare the TASK area with the starter and trace the exercise checks.
