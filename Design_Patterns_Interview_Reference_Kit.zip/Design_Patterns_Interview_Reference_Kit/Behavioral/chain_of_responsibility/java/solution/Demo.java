import java.util.*;

// Original small teaching example. Java 17+, no external libraries.
// Run: java Demo.java
// Exercise checks: java Demo.java --exercise
// Run each folder separately; every example intentionally uses the class name Demo.
public class Demo {
    static int checks;
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
    }
    static void throwsType(Class<? extends Throwable> type, Runnable action) {
        try { action.run(); }
        catch (Throwable error) {
            if (!type.isInstance(error)) throw new AssertionError("Expected " + type.getSimpleName() + ", got " + error, error);
            checks++; return;
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }
    record Handler(String name, int limit, Handler next) {
        String handle(int amount) {
            if (amount <= limit) return name;
            if (next != null) return next.handle(amount);
            throw new IllegalArgumentException("unhandled");
        }
    }
    static Handler supportChain() {
        return new Handler("Agent", 100, new Handler("Manager", 500, null));
    }

    public static void main(String[] args) {
        check(supportChain().handle(50).equals("Agent"), "agent handles small refund");
        if (args.length > 0 && args[0].equals("--exercise")) {
            check(supportChain().handle(100).equals("Agent"), "inclusive agent limit");
            check(supportChain().handle(101).equals("Manager"), "forwarded request");
            check(supportChain().handle(500).equals("Manager"), "inclusive manager limit");
            throwsType(IllegalArgumentException.class, () -> supportChain().handle(501));
        }
        System.out.println("PASS: Chain of Responsibility (" + checks + " checks)");
    }
}
