# State - Solution Notes

## The change

Assign a Cancelled state from the Draft implementation. The shared default rejects unsupported transitions.

## Why it works

Draft can pay or cancel; paid can ship; cancellation from paid is rejected in this teaching lifecycle.

## How the checks expose mistakes

Cancel a draft successfully, reject cancellation after payment, and preserve the pay-then-ship path.

## What to say in an interview

I chose this design because a lifecycle changes which operations are legal and how they behave. The trade-off is: Transitions can become inconsistent if ownership and persistence are unclear.

## Nearby alternative

State changes behavior with lifecycle transitions. Strategy selects a way to perform a task without necessarily modeling a lifecycle.

## When to simplify

A small stable enum and a clear transition table would be easier to understand than many classes.

Read the complete implementation in `java/solution/Demo.java`. Compare the TASK area with the starter and trace the exercise checks.
