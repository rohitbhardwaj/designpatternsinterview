# State

Delegate behavior to the object representing the current state.

**Category:** Behavioral

## Start here

- **3 minutes:** Read this page or Quick_Review.pdf.
- **10 minutes:** Answer Interview_QA.md aloud before revealing the answers.
- **15 minutes:** Follow Practice.md and run the Java exercise.
- **48 seconds:** Watch Pattern_Video.mp4; the clip is silent and captioned.
- **With AI:** Copy one prompt from AI_Prompts.txt, then verify the result.

## Picture it

A turnstile responds differently to a push depending on whether it is locked or unlocked.

## Use it when

A lifecycle changes which operations are legal and how they behave.

## Keep it simpler when

A small stable enum and a clear transition table would be easier to understand than many classes.

## Contract

Draft can pay or cancel; paid can ship; cancellation from paid is rejected in this teaching lifecycle.

## Nearby idea

State changes behavior with lifecycle transitions. Strategy selects a way to perform a task without necessarily modeling a lifecycle.

## Interview checkpoint

**Question:** What distinguishes State from Strategy here?

**Answer:** State behavior follows lifecycle transitions; Strategy chooses an interchangeable algorithm.

## Try it

Implement Draft.cancel to move the context to Cancelled. Keep cancellation illegal in other states.

## Evidence

Cancel a draft successfully, reject cancellation after payment, and preserve the pay-then-ship path.

## Trade-off

Transitions can become inconsistent if ownership and persistence are unclear.

## Scope

The Java exercise is a small, single-process teaching example. Its scenario can differ from the video to help you recognize the same idea in another setting.

[Open the complete visual guide](README.html) | [Interview questions](Interview_QA.md) | [Practice](Practice.md) | [Solution notes](Solution_Notes.md)
