# State - Interview Questions and Answers

These are original practice questions aligned with skills in published employer guidance. They are not attributed to an actual company interview, endorsed by an employer, or a prediction of interview frequency. See INTERVIEW_GUIDANCE.md at the kit root.

Try each answer aloud in 60-90 seconds. Model answers are examples, not scripts to memorize.

## 1. Explain the idea in plain English, then connect it to code.

**Model answer:** Delegate behavior to the object representing the current state. A turnstile responds differently to a push depending on whether it is locked or unlocked. In this exercise: Draft can pay or cancel; paid can ship; cancellation from paid is rejected in this teaching lifecycle. Assign a Cancelled state from the Draft implementation. The shared default rejects unsupported transitions.

**What to demonstrate:** Explain the collaboration before naming classes.

## 2. What distinguishes State from Strategy here?

**Model answer:** State behavior follows lifecycle transitions; Strategy chooses an interchangeable algorithm.

**What to demonstrate:** Give a concrete example that makes the distinction clear.

## 3. What nearby idea is easy to confuse with this one?

**Model answer:** State changes behavior with lifecycle transitions. Strategy selects a way to perform a task without necessarily modeling a lifecycle.

**What to demonstrate:** Compare intent and behavior, not just similar-looking diagrams.

## 4. Change request: Implement Draft.cancel to move the context to Cancelled. Keep cancellation illegal in other states.

**Model answer:** Assign a Cancelled state from the Draft implementation. The shared default rejects unsupported transitions.

**What to demonstrate:** Name the exact extension point and identify what remains stable.

## 5. Which tests would convince you that the change is correct?

**Model answer:** Cancel a draft successfully, reject cancellation after payment, and preserve the pay-then-ship path.

**What to demonstrate:** State inputs, expected outcomes, and the defect each test would expose.

## 6. What would you clarify before implementing this scenario?

**Model answer:** Ask for a transition table before introducing state classes. Refunds are outside this exercise; cancelling a paid order is forbidden.

**What to demonstrate:** Resolve a consequential ambiguity before coding.

## 7. When would you keep the design simpler or choose another approach?

**Model answer:** A small stable enum and a clear transition table would be easier to understand than many classes. Transitions can become inconsistent if ownership and persistence are unclear.

**What to demonstrate:** Explain the cost of the abstraction and the condition that justifies it.

## Self-check

Can you clarify the contract, draw the collaboration, identify the change point, write a test, and explain when a simpler approach wins? Use the original 10-point rubric in the root Interview_Approach.md.
