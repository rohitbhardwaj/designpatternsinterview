import java.util.*;

// Original small teaching example. Java 17+, no external libraries.
// Run: java Demo.java
// Exercise checks: java Demo.java --exercise
// Run each folder separately; every example intentionally uses the class name Demo.
public class Demo {
    static int checks;
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
    }
    static void throwsType(Class<? extends Throwable> type, Runnable action) {
        try { action.run(); }
        catch (Throwable error) {
            if (!type.isInstance(error)) throw new AssertionError("Expected " + type.getSimpleName() + ", got " + error, error);
            checks++; return;
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }
    interface State {
        default void pay(Order order) { throw new IllegalStateException("cannot pay"); }
        default void ship(Order order) { throw new IllegalStateException("cannot ship"); }
        default void cancel(Order order) { throw new IllegalStateException("cannot cancel"); }
    }
    static class Draft implements State {
        public void pay(Order order) { order.state = new Paid(); }
        public void cancel(Order order) {
            throw new UnsupportedOperationException("Implement Draft.cancel");
        }
    }
    static class Paid implements State { public void ship(Order order) { order.state = new Shipped(); } }
    static class Shipped implements State {}
    static class Cancelled implements State {}
    static class Order {
        State state = new Draft();
        void pay() { state.pay(this); }
        void ship() { state.ship(this); }
        void cancel() { state.cancel(this); }
    }

    public static void main(String[] args) {
        Order order = new Order(); order.pay(); order.ship();
        check(order.state instanceof Shipped, "legal lifecycle");
        throwsType(IllegalStateException.class, order::pay);
        if (args.length > 0 && args[0].equals("--exercise")) {
            Order draft = new Order(); draft.cancel(); check(draft.state instanceof Cancelled, "draft cancellation");
            Order paid = new Order(); paid.pay(); throwsType(IllegalStateException.class, paid::cancel);
            throwsType(IllegalStateException.class, draft::pay);
        }
        System.out.println("PASS: State (" + checks + " checks)");
    }
}
