# Interpreter

Evaluate a small language through an expression structure.

**Category:** Behavioral

## Start here

- **3 minutes:** Read this page or Quick_Review.pdf.
- **10 minutes:** Answer Interview_QA.md aloud before revealing the answers.
- **15 minutes:** Follow Practice.md and run the Java exercise.
- **48 seconds:** Watch Pattern_Video.mp4; the clip is silent and captioned.
- **With AI:** Copy one prompt from AI_Prompts.txt, then verify the result.

## Picture it

An expression tree breaks a sentence in a tiny language into pieces that each know their meaning.

## Use it when

A small grammar can be represented by a manageable set of expression types.

## Keep it simpler when

The language is large or untrusted input is being passed directly to an unsafe evaluation engine.

## Contract

Number returns its value; Add returns the sum of evaluating its left and right expressions.

## Nearby idea

Interpreter evaluates an expression structure. Parsing converts raw input into that structure and is a separate concern.

## Interview checkpoint

**Question:** Does Interpreter automatically parse raw input?

**Answer:** No. Parsing constructs the expression structure that interpretation evaluates.

## Try it

Implement Add.eval so nested expressions work through the Expr interface.

## Evidence

Evaluate 3+5 and (3+5)+2. The nested case exposes code that assumes both children are numeric leaves.

## Trade-off

Large grammars can create many classes and expensive recursive evaluation.

## Scope

The Java exercise is a small, single-process teaching example. Its scenario can differ from the video to help you recognize the same idea in another setting.

[Open the complete visual guide](README.html) | [Interview questions](Interview_QA.md) | [Practice](Practice.md) | [Solution notes](Solution_Notes.md)
