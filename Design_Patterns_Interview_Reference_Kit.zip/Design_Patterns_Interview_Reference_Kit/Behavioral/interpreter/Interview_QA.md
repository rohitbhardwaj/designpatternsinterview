# Interpreter - Interview Questions and Answers

These are original practice questions aligned with skills in published employer guidance. They are not attributed to an actual company interview, endorsed by an employer, or a prediction of interview frequency. See INTERVIEW_GUIDANCE.md at the kit root.

Try each answer aloud in 60-90 seconds. Model answers are examples, not scripts to memorize.

## 1. Explain the idea in plain English, then connect it to code.

**Model answer:** Evaluate a small language through an expression structure. An expression tree breaks a sentence in a tiny language into pieces that each know their meaning. In this exercise: Number returns its value; Add returns the sum of evaluating its left and right expressions. Recursively evaluate the operands, then add the results. No string parsing or scripting engine is needed.

**What to demonstrate:** Explain the collaboration before naming classes.

## 2. Does Interpreter automatically parse raw input?

**Model answer:** No. Parsing constructs the expression structure that interpretation evaluates.

**What to demonstrate:** Give a concrete example that makes the distinction clear.

## 3. What nearby idea is easy to confuse with this one?

**Model answer:** Interpreter evaluates an expression structure. Parsing converts raw input into that structure and is a separate concern.

**What to demonstrate:** Compare intent and behavior, not just similar-looking diagrams.

## 4. Change request: Implement Add.eval so nested expressions work through the Expr interface.

**Model answer:** Recursively evaluate the operands, then add the results. No string parsing or scripting engine is needed.

**What to demonstrate:** Name the exact extension point and identify what remains stable.

## 5. Which tests would convince you that the change is correct?

**Model answer:** Evaluate 3+5 and (3+5)+2. The nested case exposes code that assumes both children are numeric leaves.

**What to demonstrate:** State inputs, expected outcomes, and the defect each test would expose.

## 6. What would you clarify before implementing this scenario?

**Model answer:** Ask what grammar, numeric range, and depth are supported. This exercise has integer literals and addition with small bounded values.

**What to demonstrate:** Resolve a consequential ambiguity before coding.

## 7. When would you keep the design simpler or choose another approach?

**Model answer:** The language is large or untrusted input is being passed directly to an unsafe evaluation engine. Large grammars can create many classes and expensive recursive evaluation.

**What to demonstrate:** Explain the cost of the abstraction and the condition that justifies it.

## Self-check

Can you clarify the contract, draw the collaboration, identify the change point, write a test, and explain when a simpler approach wins? Use the original 10-point rubric in the root Interview_Approach.md.
