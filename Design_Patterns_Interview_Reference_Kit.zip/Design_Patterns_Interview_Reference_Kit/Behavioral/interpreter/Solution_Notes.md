# Interpreter - Solution Notes

## The change

Recursively evaluate the operands, then add the results. No string parsing or scripting engine is needed.

## Why it works

Number returns its value; Add returns the sum of evaluating its left and right expressions.

## How the checks expose mistakes

Evaluate 3+5 and (3+5)+2. The nested case exposes code that assumes both children are numeric leaves.

## What to say in an interview

I chose this design because a small grammar can be represented by a manageable set of expression types. The trade-off is: Large grammars can create many classes and expensive recursive evaluation.

## Nearby alternative

Interpreter evaluates an expression structure. Parsing converts raw input into that structure and is a separate concern.

## When to simplify

The language is large or untrusted input is being passed directly to an unsafe evaluation engine.

Read the complete implementation in `java/solution/Demo.java`. Compare the TASK area with the starter and trace the exercise checks.
