import java.util.*;

// Original small teaching example. Java 17+, no external libraries.
// Run: java Demo.java
// Exercise checks: java Demo.java --exercise
// Run each folder separately; every example intentionally uses the class name Demo.
public class Demo {
    static int checks;
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
    }
    static void throwsType(Class<? extends Throwable> type, Runnable action) {
        try { action.run(); }
        catch (Throwable error) {
            if (!type.isInstance(error)) throw new AssertionError("Expected " + type.getSimpleName() + ", got " + error, error);
            checks++; return;
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }
    interface Expr { int eval(); }
    record NumberExpr(int value) implements Expr { public int eval() { return value; } }
    record Add(Expr left, Expr right) implements Expr {
        public int eval() {
            throw new UnsupportedOperationException("Implement Add.eval");
        }
    }

    public static void main(String[] args) {
        check(new NumberExpr(3).eval() == 3, "terminal expression");
        if (args.length > 0 && args[0].equals("--exercise")) {
            Expr sum = new Add(new NumberExpr(3), new NumberExpr(5));
            check(sum.eval() == 8, "simple addition");
            check(new Add(sum, new NumberExpr(2)).eval() == 10, "nested expression");
        }
        System.out.println("PASS: Interpreter (" + checks + " checks)");
    }
}
