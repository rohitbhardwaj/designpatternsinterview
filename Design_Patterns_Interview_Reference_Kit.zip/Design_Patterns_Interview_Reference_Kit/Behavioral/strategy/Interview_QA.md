# Strategy - Interview Questions and Answers

These are original practice questions aligned with skills in published employer guidance. They are not attributed to an actual company interview, endorsed by an employer, or a prediction of interview frequency. See INTERVIEW_GUIDANCE.md at the kit root.

Try each answer aloud in 60-90 seconds. Model answers are examples, not scripts to memorize.

## 1. Explain the idea in plain English, then connect it to code.

**Model answer:** Select an interchangeable algorithm behind one contract. A navigation app can choose a walking or driving route while keeping the same destination workflow. In this exercise: Checkout delegates to the supplied payment algorithm and preserves the exact amount. Return the wallet reference through PaymentStrategy. Select the implementation outside Checkout.

**What to demonstrate:** Explain the collaboration before naming classes.

## 2. Who decides which strategy to supply?

**Model answer:** A client, configuration, or selection policy outside the stable algorithm consumer.

**What to demonstrate:** Give a concrete example that makes the distinction clear.

## 3. What nearby idea is easy to confuse with this one?

**Model answer:** Strategy selects an algorithm. State follows a lifecycle; Template Method varies inherited steps rather than delegated behavior.

**What to demonstrate:** Compare intent and behavior, not just similar-looking diagrams.

## 4. Change request: Implement WalletPayment and use it through the unchanged Checkout.

**Model answer:** Return the wallet reference through PaymentStrategy. Select the implementation outside Checkout.

**What to demonstrate:** Name the exact extension point and identify what remains stable.

## 5. Which tests would convince you that the change is correct?

**Model answer:** Check card and wallet results for the same amount and verify the wallet receives a zero amount without altering the contract.

**What to demonstrate:** State inputs, expected outcomes, and the defect each test would expose.

## 6. What would you clarify before implementing this scenario?

**Model answer:** Ask who selects the algorithm and whether providers share result semantics. This toy contract returns a provider-tagged reference only.

**What to demonstrate:** Resolve a consequential ambiguity before coding.

## 7. When would you keep the design simpler or choose another approach?

**Model answer:** The algorithms cannot honestly satisfy a shared contract or a single stable rule needs no variation point. A strategy contract can hide important differences in failure or settlement semantics.

**What to demonstrate:** Explain the cost of the abstraction and the condition that justifies it.

## Self-check

Can you clarify the contract, draw the collaboration, identify the change point, write a test, and explain when a simpler approach wins? Use the original 10-point rubric in the root Interview_Approach.md.
