import java.util.*;

// Original small teaching example. Java 17+, no external libraries.
// Run: java Demo.java
// Exercise checks: java Demo.java --exercise
// Run each folder separately; every example intentionally uses the class name Demo.
public class Demo {
    static int checks;
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
    }
    static void throwsType(Class<? extends Throwable> type, Runnable action) {
        try { action.run(); }
        catch (Throwable error) {
            if (!type.isInstance(error)) throw new AssertionError("Expected " + type.getSimpleName() + ", got " + error, error);
            checks++; return;
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }
    interface PaymentStrategy { String pay(int cents); }
    record Checkout(PaymentStrategy strategy) { String pay(int cents) { return strategy.pay(cents); } }
    static class CardPayment implements PaymentStrategy { public String pay(int cents) { return "card:" + cents; } }
    static class WalletPayment implements PaymentStrategy { public String pay(int cents) {
        return "wallet:" + cents;
    } }

    public static void main(String[] args) {
        check(new Checkout(new CardPayment()).pay(1200).equals("card:1200"), "existing algorithm");
        if (args.length > 0 && args[0].equals("--exercise")) {
            check(new Checkout(new WalletPayment()).pay(1200).equals("wallet:1200"), "new algorithm");
            check(new Checkout(new WalletPayment()).pay(0).equals("wallet:0"), "amount preserved");
        }
        System.out.println("PASS: Strategy (" + checks + " checks)");
    }
}
