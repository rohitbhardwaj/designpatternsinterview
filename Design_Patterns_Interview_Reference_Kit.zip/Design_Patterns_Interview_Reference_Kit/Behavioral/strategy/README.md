# Strategy

Select an interchangeable algorithm behind one contract.

**Category:** Behavioral

## Start here

- **3 minutes:** Read this page or Quick_Review.pdf.
- **10 minutes:** Answer Interview_QA.md aloud before revealing the answers.
- **15 minutes:** Follow Practice.md and run the Java exercise.
- **48 seconds:** Watch Pattern_Video.mp4; the clip is silent and captioned.
- **With AI:** Copy one prompt from AI_Prompts.txt, then verify the result.

## Picture it

A navigation app can choose a walking or driving route while keeping the same destination workflow.

## Use it when

A client needs interchangeable algorithms with equivalent advertised guarantees.

## Keep it simpler when

The algorithms cannot honestly satisfy a shared contract or a single stable rule needs no variation point.

## Contract

Checkout delegates to the supplied payment algorithm and preserves the exact amount.

## Nearby idea

Strategy selects an algorithm. State follows a lifecycle; Template Method varies inherited steps rather than delegated behavior.

## Interview checkpoint

**Question:** Who decides which strategy to supply?

**Answer:** A client, configuration, or selection policy outside the stable algorithm consumer.

## Try it

Implement WalletPayment and use it through the unchanged Checkout.

## Evidence

Check card and wallet results for the same amount and verify the wallet receives a zero amount without altering the contract.

## Trade-off

A strategy contract can hide important differences in failure or settlement semantics.

## Scope

The Java exercise is a small, single-process teaching example. Its scenario can differ from the video to help you recognize the same idea in another setting.

[Open the complete visual guide](README.html) | [Interview questions](Interview_QA.md) | [Practice](Practice.md) | [Solution notes](Solution_Notes.md)
