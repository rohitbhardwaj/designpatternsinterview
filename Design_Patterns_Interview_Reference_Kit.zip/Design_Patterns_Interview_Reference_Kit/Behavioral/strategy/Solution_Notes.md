# Strategy - Solution Notes

## The change

Return the wallet reference through PaymentStrategy. Select the implementation outside Checkout.

## Why it works

Checkout delegates to the supplied payment algorithm and preserves the exact amount.

## How the checks expose mistakes

Check card and wallet results for the same amount and verify the wallet receives a zero amount without altering the contract.

## What to say in an interview

I chose this design because a client needs interchangeable algorithms with equivalent advertised guarantees. The trade-off is: A strategy contract can hide important differences in failure or settlement semantics.

## Nearby alternative

Strategy selects an algorithm. State follows a lifecycle; Template Method varies inherited steps rather than delegated behavior.

## When to simplify

The algorithms cannot honestly satisfy a shared contract or a single stable rule needs no variation point.

Read the complete implementation in `java/solution/Demo.java`. Compare the TASK area with the starter and trace the exercise checks.
