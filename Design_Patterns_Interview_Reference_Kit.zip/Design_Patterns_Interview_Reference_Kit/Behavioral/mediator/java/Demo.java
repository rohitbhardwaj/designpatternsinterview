import java.util.*;

// Original small teaching example. Java 17+, no external libraries.
// Run: java Demo.java
// Exercise checks: java Demo.java --exercise
// Run each folder separately; every example intentionally uses the class name Demo.
public class Demo {
    static int checks;
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
    }
    static void throwsType(Class<? extends Throwable> type, Runnable action) {
        try { action.run(); }
        catch (Throwable error) {
            if (!type.isInstance(error)) throw new AssertionError("Expected " + type.getSimpleName() + ", got " + error, error);
            checks++; return;
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }
    static class User { final List<String> inbox = new ArrayList<>(); }
    static class ChatRoom {
        final Set<User> members = new LinkedHashSet<>();
        void join(User user) { members.add(user); }
        void send(User sender, String message) {
            throw new UnsupportedOperationException("Implement ChatRoom.send");
        }
    }

    public static void main(String[] args) {
        ChatRoom room = new ChatRoom(); User alice = new User(), bob = new User(), chen = new User();
        room.join(alice); room.join(bob); room.join(chen);
        check(room.members.size() == 3, "registered colleagues");
        if (args.length > 0 && args[0].equals("--exercise")) {
            room.send(alice, "hello");
            check(alice.inbox.isEmpty(), "no sender echo");
            check(bob.inbox.equals(List.of("hello")) && chen.inbox.equals(List.of("hello")), "one delivery each");
            throwsType(IllegalArgumentException.class, () -> room.send(new User(), "outsider"));
        }
        System.out.println("PASS: Mediator (" + checks + " checks)");
    }
}
