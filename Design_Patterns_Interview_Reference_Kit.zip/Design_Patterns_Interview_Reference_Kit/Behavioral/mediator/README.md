# Mediator

Put interaction rules in a coordinator that colleagues use.

**Category:** Behavioral

## Start here

- **3 minutes:** Read this page or Quick_Review.pdf.
- **10 minutes:** Answer Interview_QA.md aloud before revealing the answers.
- **15 minutes:** Follow Practice.md and run the Java exercise.
- **48 seconds:** Watch Pattern_Video.mp4; the clip is silent and captioned.
- **With AI:** Copy one prompt from AI_Prompts.txt, then verify the result.

## Picture it

An air-traffic controller coordinates pilots so every pilot does not negotiate with every other pilot.

## Use it when

Interaction rules among colleagues would otherwise be duplicated across many peer connections.

## Keep it simpler when

The coordinator starts owning unrelated domain logic and becomes a God object.

## Contract

A room sends one message to every registered participant except the sender.

## Nearby idea

Mediator owns coordination rules among colleagues. Observer provides a subject-to-subscribers notification relationship.

## Interview checkpoint

**Question:** Where should the rule excluding the sender from broadcast live?

**Answer:** In the mediator’s coordination policy.

## Try it

Implement ChatRoom.send so sender exclusion is enforced centrally.

## Evidence

Send from Alice to a room with Alice, Bob, and Chen; Alice receives zero messages and the others receive one each.

## Trade-off

The mediator can become complex if it owns unrelated domain behavior.

## Scope

The Java exercise is a small, single-process teaching example. Its scenario can differ from the video to help you recognize the same idea in another setting.

[Open the complete visual guide](README.html) | [Interview questions](Interview_QA.md) | [Practice](Practice.md) | [Solution notes](Solution_Notes.md)
