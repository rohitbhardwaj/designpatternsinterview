# Mediator - Solution Notes

## The change

Loop over the room membership, skip the sender by identity, and deliver once to each other participant.

## Why it works

A room sends one message to every registered participant except the sender.

## How the checks expose mistakes

Send from Alice to a room with Alice, Bob, and Chen; Alice receives zero messages and the others receive one each.

## What to say in an interview

I chose this design because interaction rules among colleagues would otherwise be duplicated across many peer connections. The trade-off is: The mediator can become complex if it owns unrelated domain behavior.

## Nearby alternative

Mediator owns coordination rules among colleagues. Observer provides a subject-to-subscribers notification relationship.

## When to simplify

The coordinator starts owning unrelated domain logic and becomes a God object.

Read the complete implementation in `java/solution/Demo.java`. Compare the TASK area with the starter and trace the exercise checks.
