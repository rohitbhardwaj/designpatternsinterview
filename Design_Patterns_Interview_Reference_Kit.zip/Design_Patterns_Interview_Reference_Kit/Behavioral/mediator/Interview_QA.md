# Mediator - Interview Questions and Answers

These are original practice questions aligned with skills in published employer guidance. They are not attributed to an actual company interview, endorsed by an employer, or a prediction of interview frequency. See INTERVIEW_GUIDANCE.md at the kit root.

Try each answer aloud in 60-90 seconds. Model answers are examples, not scripts to memorize.

## 1. Explain the idea in plain English, then connect it to code.

**Model answer:** Put interaction rules in a coordinator that colleagues use. An air-traffic controller coordinates pilots so every pilot does not negotiate with every other pilot. In this exercise: A room sends one message to every registered participant except the sender. Loop over the room membership, skip the sender by identity, and deliver once to each other participant.

**What to demonstrate:** Explain the collaboration before naming classes.

## 2. Where should the rule excluding the sender from broadcast live?

**Model answer:** In the mediator’s coordination policy.

**What to demonstrate:** Give a concrete example that makes the distinction clear.

## 3. What nearby idea is easy to confuse with this one?

**Model answer:** Mediator owns coordination rules among colleagues. Observer provides a subject-to-subscribers notification relationship.

**What to demonstrate:** Compare intent and behavior, not just similar-looking diagrams.

## 4. Change request: Implement ChatRoom.send so sender exclusion is enforced centrally.

**Model answer:** Loop over the room membership, skip the sender by identity, and deliver once to each other participant.

**What to demonstrate:** Name the exact extension point and identify what remains stable.

## 5. Which tests would convince you that the change is correct?

**Model answer:** Send from Alice to a room with Alice, Bob, and Chen; Alice receives zero messages and the others receive one each.

**What to demonstrate:** State inputs, expected outcomes, and the defect each test would expose.

## 6. What would you clarify before implementing this scenario?

**Model answer:** Ask about membership, echo-to-sender, and duplicates. This small room uses a set of participant identities and excludes the sender.

**What to demonstrate:** Resolve a consequential ambiguity before coding.

## 7. When would you keep the design simpler or choose another approach?

**Model answer:** The coordinator starts owning unrelated domain logic and becomes a God object. The mediator can become complex if it owns unrelated domain behavior.

**What to demonstrate:** Explain the cost of the abstraction and the condition that justifies it.

## Self-check

Can you clarify the contract, draw the collaboration, identify the change point, write a test, and explain when a simpler approach wins? Use the original 10-point rubric in the root Interview_Approach.md.
