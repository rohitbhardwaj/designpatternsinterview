import java.util.*;

// Original small teaching example. Java 17+, no external libraries.
// Run: java Demo.java
// Exercise checks: java Demo.java --exercise
// Run each folder separately; every example intentionally uses the class name Demo.
public class Demo {
    static int checks;
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
    }
    static void throwsType(Class<? extends Throwable> type, Runnable action) {
        try { action.run(); }
        catch (Throwable error) {
            if (!type.isInstance(error)) throw new AssertionError("Expected " + type.getSimpleName() + ", got " + error, error);
            checks++; return;
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }
    record Report(String title, String format) {}
    static class Builder {
        String title = "", format = "CSV";
        Builder title(String value) { title = Objects.requireNonNull(value); return this; }
        Builder format(String value) { format = Objects.requireNonNull(value); return this; }
        Report build() {
            if (format.equals("PDF") && title.isBlank()) throw new IllegalArgumentException("PDF requires title");
                    return new Report(title, format);
        }
    }

    public static void main(String[] args) {
        check(new Builder().title("Sales").format("PDF").build().title().equals("Sales"), "valid report");
        if (args.length > 0 && args[0].equals("--exercise")) {
            throwsType(IllegalArgumentException.class, () -> new Builder().format("PDF").build());
            check(new Builder().build().format().equals("CSV"), "allowed blank CSV title");
        }
        System.out.println("PASS: Builder (" + checks + " checks)");
    }
}
