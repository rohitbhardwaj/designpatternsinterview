# Builder

Assemble a complex object through clear construction steps.

**Category:** Creational

## Start here

- **3 minutes:** Read this page or Quick_Review.pdf.
- **10 minutes:** Answer Interview_QA.md aloud before revealing the answers.
- **15 minutes:** Follow Practice.md and run the Java exercise.
- **48 seconds:** Watch Pattern_Video.mp4; the clip is silent and captioned.
- **With AI:** Copy one prompt from AI_Prompts.txt, then verify the result.

## Picture it

A meal order collects named choices and is checked before it reaches the kitchen.

## Use it when

Construction has several meaningful options or cross-field rules.

## Keep it simpler when

A small value object has two obvious fields and no complex construction rules.

## Contract

A PDF report requires a nonblank title; validation happens before the Report is returned.

## Nearby idea

Builder assembles one object step by step. Abstract Factory supplies a compatible family of objects.

## Interview checkpoint

**Question:** Where should a cross-field invariant be checked?

**Answer:** At a boundary such as build(), after the required configuration is available.

## Try it

Complete build to reject a blank title for PDF and return an immutable Report otherwise.

## Evidence

Check a valid PDF report, a blank PDF title, and a blank CSV title that the stated contract allows.

## Trade-off

Fluent syntax alone does not guarantee validation or immutability.

## Scope

The Java exercise is a small, single-process teaching example. Its scenario can differ from the video to help you recognize the same idea in another setting.

[Open the complete visual guide](README.html) | [Interview questions](Interview_QA.md) | [Practice](Practice.md) | [Solution notes](Solution_Notes.md)
