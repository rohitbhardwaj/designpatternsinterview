# Builder - Solution Notes

## The change

Validate the finished configuration in build, then create the record. Fluent setters alone do not enforce invariants.

## Why it works

A PDF report requires a nonblank title; validation happens before the Report is returned.

## How the checks expose mistakes

Check a valid PDF report, a blank PDF title, and a blank CSV title that the stated contract allows.

## What to say in an interview

I chose this design because construction has several meaningful options or cross-field rules. The trade-off is: Fluent syntax alone does not guarantee validation or immutability.

## Nearby alternative

Builder assembles one object step by step. Abstract Factory supplies a compatible family of objects.

## When to simplify

A small value object has two obvious fields and no complex construction rules.

Read the complete implementation in `java/solution/Demo.java`. Compare the TASK area with the starter and trace the exercise checks.
