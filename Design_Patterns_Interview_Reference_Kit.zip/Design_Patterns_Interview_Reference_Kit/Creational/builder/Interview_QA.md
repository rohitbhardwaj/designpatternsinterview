# Builder - Interview Questions and Answers

These are original practice questions aligned with skills in published employer guidance. They are not attributed to an actual company interview, endorsed by an employer, or a prediction of interview frequency. See INTERVIEW_GUIDANCE.md at the kit root.

Try each answer aloud in 60-90 seconds. Model answers are examples, not scripts to memorize.

## 1. Explain the idea in plain English, then connect it to code.

**Model answer:** Assemble a complex object through clear construction steps. A meal order collects named choices and is checked before it reaches the kitchen. In this exercise: A PDF report requires a nonblank title; validation happens before the Report is returned. Validate the finished configuration in build, then create the record. Fluent setters alone do not enforce invariants.

**What to demonstrate:** Explain the collaboration before naming classes.

## 2. Where should a cross-field invariant be checked?

**Model answer:** At a boundary such as build(), after the required configuration is available.

**What to demonstrate:** Give a concrete example that makes the distinction clear.

## 3. What nearby idea is easy to confuse with this one?

**Model answer:** Builder assembles one object step by step. Abstract Factory supplies a compatible family of objects.

**What to demonstrate:** Compare intent and behavior, not just similar-looking diagrams.

## 4. Change request: Complete build to reject a blank title for PDF and return an immutable Report otherwise.

**Model answer:** Validate the finished configuration in build, then create the record. Fluent setters alone do not enforce invariants.

**What to demonstrate:** Name the exact extension point and identify what remains stable.

## 5. Which tests would convince you that the change is correct?

**Model answer:** Check a valid PDF report, a blank PDF title, and a blank CSV title that the stated contract allows.

**What to demonstrate:** State inputs, expected outcomes, and the defect each test would expose.

## 6. What would you clarify before implementing this scenario?

**Model answer:** Ask which fields are mandatory and which combinations are invalid. In this exercise only PDF requires a nonblank title.

**What to demonstrate:** Resolve a consequential ambiguity before coding.

## 7. When would you keep the design simpler or choose another approach?

**Model answer:** A small value object has two obvious fields and no complex construction rules. Fluent syntax alone does not guarantee validation or immutability.

**What to demonstrate:** Explain the cost of the abstraction and the condition that justifies it.

## Self-check

Can you clarify the contract, draw the collaboration, identify the change point, write a test, and explain when a simpler approach wins? Use the original 10-point rubric in the root Interview_Approach.md.
