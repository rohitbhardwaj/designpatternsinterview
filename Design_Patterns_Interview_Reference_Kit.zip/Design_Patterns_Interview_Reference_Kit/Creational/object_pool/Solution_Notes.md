# Object Pool - Solution Notes

## The change

Acquire once, run the job, and release in finally. This single-threaded toy pool fails immediately when exhausted.

## Why it works

A one-resource pool rejects a second acquire and always returns the resource after use, including failure.

## How the checks expose mistakes

Make the job throw, then immediately acquire again. Also check that a simultaneous second lease is rejected.

## What to say in an interview

I chose this design because expensive reusable resources need bounded ownership and explicit release. The trade-off is: Leaked leases, stale state, and unbounded waiting can exhaust the system.

## Nearby alternative

A pool loans resources temporarily. A cache reuses lookup results; it does not necessarily enforce exclusive borrowing.

## When to simplify

Objects are cheap to allocate or cleanup and ownership become more expensive than construction.

Read the complete implementation in `java/solution/Demo.java`. Compare the TASK area with the starter and trace the exercise checks.
