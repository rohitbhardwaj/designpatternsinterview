import java.util.*;

// Original small teaching example. Java 17+, no external libraries.
// Run: java Demo.java
// Exercise checks: java Demo.java --exercise
// Run each folder separately; every example intentionally uses the class name Demo.
public class Demo {
    static int checks;
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
    }
    static void throwsType(Class<? extends Throwable> type, Runnable action) {
        try { action.run(); }
        catch (Throwable error) {
            if (!type.isInstance(error)) throw new AssertionError("Expected " + type.getSimpleName() + ", got " + error, error);
            checks++; return;
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }
    static class Pool {
        boolean borrowed;
        String acquire() { if (borrowed) throw new IllegalStateException("exhausted"); borrowed = true; return "connection"; }
        void release() { if (!borrowed) throw new IllegalStateException("not borrowed"); borrowed = false; }
    }
    static void use(Pool pool, Runnable job) {
        pool.acquire(); job.run(); pool.release(); // TASK: release after failure too.
    }

    public static void main(String[] args) {
        Pool pool = new Pool();
        use(pool, () -> {});
        check(!pool.borrowed, "normal release");
        if (args.length > 0 && args[0].equals("--exercise")) {
            throwsType(IllegalArgumentException.class, () -> use(pool, () -> { throw new IllegalArgumentException("job failed"); }));
            check(pool.acquire().equals("connection"), "resource reusable after failure");
            throwsType(IllegalStateException.class, pool::acquire);
            pool.release();
        }
        System.out.println("PASS: Object Pool (" + checks + " checks)");
    }
}
