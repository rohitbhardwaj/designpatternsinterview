# Object Pool - Interview Questions and Answers

These are original practice questions aligned with skills in published employer guidance. They are not attributed to an actual company interview, endorsed by an employer, or a prediction of interview frequency. See INTERVIEW_GUIDANCE.md at the kit root.

Try each answer aloud in 60-90 seconds. Model answers are examples, not scripts to memorize.

## 1. Explain the idea in plain English, then connect it to code.

**Model answer:** Borrow and return a bounded set of expensive resources. A library lends a limited number of books and records which ones must be returned. In this exercise: A one-resource pool rejects a second acquire and always returns the resource after use, including failure. Acquire once, run the job, and release in finally. This single-threaded toy pool fails immediately when exhausted.

**What to demonstrate:** Explain the collaboration before naming classes.

## 2. What happens when every resource is borrowed?

**Model answer:** A documented bounded wait, timeout, or rejection policy handles exhaustion.

**What to demonstrate:** Give a concrete example that makes the distinction clear.

## 3. What nearby idea is easy to confuse with this one?

**Model answer:** A pool loans resources temporarily. A cache reuses lookup results; it does not necessarily enforce exclusive borrowing.

**What to demonstrate:** Compare intent and behavior, not just similar-looking diagrams.

## 4. Change request: Implement use so the resource is released in a finally block when the supplied job fails.

**Model answer:** Acquire once, run the job, and release in finally. This single-threaded toy pool fails immediately when exhausted.

**What to demonstrate:** Name the exact extension point and identify what remains stable.

## 5. Which tests would convince you that the change is correct?

**Model answer:** Make the job throw, then immediately acquire again. Also check that a simultaneous second lease is rejected.

**What to demonstrate:** State inputs, expected outcomes, and the defect each test would expose.

## 6. What would you clarify before implementing this scenario?

**Model answer:** Ask how exhaustion, reset, and concurrency are handled. Here exhaustion fails fast, there is one resource, and callers are sequential.

**What to demonstrate:** Resolve a consequential ambiguity before coding.

## 7. When would you keep the design simpler or choose another approach?

**Model answer:** Objects are cheap to allocate or cleanup and ownership become more expensive than construction. Leaked leases, stale state, and unbounded waiting can exhaust the system.

**What to demonstrate:** Explain the cost of the abstraction and the condition that justifies it.

## Self-check

Can you clarify the contract, draw the collaboration, identify the change point, write a test, and explain when a simpler approach wins? Use the original 10-point rubric in the root Interview_Approach.md.
