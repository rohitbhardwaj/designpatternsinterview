# Object Pool

Borrow and return a bounded set of expensive resources.

**Category:** Creational - additional creation idiom outside the original GoF catalog.

## Start here

- **3 minutes:** Read this page or Quick_Review.pdf.
- **10 minutes:** Answer Interview_QA.md aloud before revealing the answers.
- **15 minutes:** Follow Practice.md and run the Java exercise.
- **48 seconds:** Watch Pattern_Video.mp4; the clip is silent and captioned.
- **With AI:** Copy one prompt from AI_Prompts.txt, then verify the result.

## Picture it

A library lends a limited number of books and records which ones must be returned.

## Use it when

Expensive reusable resources need bounded ownership and explicit release.

## Keep it simpler when

Objects are cheap to allocate or cleanup and ownership become more expensive than construction.

## Contract

A one-resource pool rejects a second acquire and always returns the resource after use, including failure.

## Nearby idea

A pool loans resources temporarily. A cache reuses lookup results; it does not necessarily enforce exclusive borrowing.

## Interview checkpoint

**Question:** What happens when every resource is borrowed?

**Answer:** A documented bounded wait, timeout, or rejection policy handles exhaustion.

## Try it

Implement use so the resource is released in a finally block when the supplied job fails.

## Evidence

Make the job throw, then immediately acquire again. Also check that a simultaneous second lease is rejected.

## Trade-off

Leaked leases, stale state, and unbounded waiting can exhaust the system.

## Scope

The Java exercise is a small, single-process teaching example. Its scenario can differ from the video to help you recognize the same idea in another setting.

[Open the complete visual guide](README.html) | [Interview questions](Interview_QA.md) | [Practice](Practice.md) | [Solution notes](Solution_Notes.md)
