# Factory Method

A creator delegates product creation to an overridable method.

**Category:** Creational

## Start here

- **3 minutes:** Read this page or Quick_Review.pdf.
- **10 minutes:** Answer Interview_QA.md aloud before revealing the answers.
- **15 minutes:** Follow Practice.md and run the Java exercise.
- **48 seconds:** Watch Pattern_Video.mp4; the clip is silent and captioned.
- **With AI:** Copy one prompt from AI_Prompts.txt, then verify the result.

## Picture it

A production line keeps its sequence while a specialist station supplies a particular part.

## Use it when

A genuine creator hierarchy needs to vary the product used by a shared workflow.

## Keep it simpler when

An injected supplier or simple creation function would solve the same problem with fewer classes.

## Contract

The inherited process uses the product supplied by createDocument and retains its save step.

## Nearby idea

Factory Method varies product creation through subclassing. Template Method can vary other steps of a larger algorithm.

## Interview checkpoint

**Question:** What varies here: the whole workflow or the product creation step?

**Answer:** The product creation step varies while the creator can retain the workflow.

## Try it

Complete CsvProcessor.createDocument without overriding process.

## Evidence

Check both processor outputs contain their format and the shared saved suffix.

## Trade-off

Subclass hierarchies can become harder to navigate than injected factories.

## Scope

The Java exercise is a small, single-process teaching example. Its scenario can differ from the video to help you recognize the same idea in another setting.

[Open the complete visual guide](README.html) | [Interview questions](Interview_QA.md) | [Practice](Practice.md) | [Solution notes](Solution_Notes.md)
