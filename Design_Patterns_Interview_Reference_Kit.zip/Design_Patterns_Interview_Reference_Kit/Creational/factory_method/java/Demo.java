import java.util.*;

// Original small teaching example. Java 17+, no external libraries.
// Run: java Demo.java
// Exercise checks: java Demo.java --exercise
// Run each folder separately; every example intentionally uses the class name Demo.
public class Demo {
    static int checks;
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
    }
    static void throwsType(Class<? extends Throwable> type, Runnable action) {
        try { action.run(); }
        catch (Throwable error) {
            if (!type.isInstance(error)) throw new AssertionError("Expected " + type.getSimpleName() + ", got " + error, error);
            checks++; return;
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }
    interface Document { String render(); }
    abstract static class Processor {
        abstract Document createDocument();
        final String process() { return createDocument().render() + ":saved"; }
    }
    static class PdfProcessor extends Processor { Document createDocument() { return () -> "pdf"; } }
    static class CsvProcessor extends Processor {
        Document createDocument() {
            throw new UnsupportedOperationException("Implement CsvProcessor.createDocument");
        }
    }

    public static void main(String[] args) {
        check(new PdfProcessor().process().equals("pdf:saved"), "existing creator");
        if (args.length > 0 && args[0].equals("--exercise")) {
            check(new CsvProcessor().process().equals("csv:saved"), "new creator, same workflow");
        }
        System.out.println("PASS: Factory Method (" + checks + " checks)");
    }
}
