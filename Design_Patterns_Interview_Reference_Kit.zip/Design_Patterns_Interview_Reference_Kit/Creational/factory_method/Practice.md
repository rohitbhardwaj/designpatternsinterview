# Factory Method - 15-minute practice

## The task

Complete CsvProcessor.createDocument without overriding process.

**Required behavior:** The inherited process uses the product supplied by createDocument and retains its save step.

**Clarify first:** Ask which workflow steps are fixed. Here processing and saving are fixed; only product creation varies.

## Run it

Use Java 17 or later. No Maven, Gradle, JUnit, account, or API key is needed.
Open a terminal in this pattern folder, then run:

```sh
cd java
java Demo.java
```

The baseline should print `PASS`. It demonstrates the starting behavior.

```sh
java Demo.java --exercise
```

This deliberately fails in the starter. Read the error, then edit the one TASK/TODO area in `Demo.java`. Some starters throw an explicit exception; others contain a plausible incomplete implementation. Leave the checks in `main` intact.

## Work in small steps

1. In your own words, state the contract above. Name the component that should change.
2. Predict the exercise failure before running it.
3. Implement the smallest change and rerun both commands.
4. Explain why the change fits this principle or pattern.
5. Add one meaningful check beyond those supplied.

**Cases to understand:** Check both processor outputs contain their format and the shared saved suffix.

## Done means

- Both commands print `PASS`.
- You can explain the call flow without reading the solution.
- You can describe this trade-off: Subclass hierarchies can become harder to navigate than injected factories.

## If you get stuck

First hint: identify the advertised contract and the extension point. Then read `Solution_Notes.md` in the pattern folder. To run the complete solution from inside `java`:

```sh
java solution/Demo.java --exercise
```

Do not compile all pattern files together: each folder intentionally uses its own standalone `Demo` class. These are small teaching examples, not complete production components.
