# Factory Method - Interview Questions and Answers

These are original practice questions aligned with skills in published employer guidance. They are not attributed to an actual company interview, endorsed by an employer, or a prediction of interview frequency. See INTERVIEW_GUIDANCE.md at the kit root.

Try each answer aloud in 60-90 seconds. Model answers are examples, not scripts to memorize.

## 1. Explain the idea in plain English, then connect it to code.

**Model answer:** A creator delegates product creation to an overridable method. A production line keeps its sequence while a specialist station supplies a particular part. In this exercise: The inherited process uses the product supplied by createDocument and retains its save step. Return a CSV Document from the subclass factory method. The inherited workflow remains unchanged.

**What to demonstrate:** Explain the collaboration before naming classes.

## 2. What varies here: the whole workflow or the product creation step?

**Model answer:** The product creation step varies while the creator can retain the workflow.

**What to demonstrate:** Give a concrete example that makes the distinction clear.

## 3. What nearby idea is easy to confuse with this one?

**Model answer:** Factory Method varies product creation through subclassing. Template Method can vary other steps of a larger algorithm.

**What to demonstrate:** Compare intent and behavior, not just similar-looking diagrams.

## 4. Change request: Complete CsvProcessor.createDocument without overriding process.

**Model answer:** Return a CSV Document from the subclass factory method. The inherited workflow remains unchanged.

**What to demonstrate:** Name the exact extension point and identify what remains stable.

## 5. Which tests would convince you that the change is correct?

**Model answer:** Check both processor outputs contain their format and the shared saved suffix.

**What to demonstrate:** State inputs, expected outcomes, and the defect each test would expose.

## 6. What would you clarify before implementing this scenario?

**Model answer:** Ask which workflow steps are fixed. Here processing and saving are fixed; only product creation varies.

**What to demonstrate:** Resolve a consequential ambiguity before coding.

## 7. When would you keep the design simpler or choose another approach?

**Model answer:** An injected supplier or simple creation function would solve the same problem with fewer classes. Subclass hierarchies can become harder to navigate than injected factories.

**What to demonstrate:** Explain the cost of the abstraction and the condition that justifies it.

## Self-check

Can you clarify the contract, draw the collaboration, identify the change point, write a test, and explain when a simpler approach wins? Use the original 10-point rubric in the root Interview_Approach.md.
