# Factory Method - Solution Notes

## The change

Return a CSV Document from the subclass factory method. The inherited workflow remains unchanged.

## Why it works

The inherited process uses the product supplied by createDocument and retains its save step.

## How the checks expose mistakes

Check both processor outputs contain their format and the shared saved suffix.

## What to say in an interview

I chose this design because a genuine creator hierarchy needs to vary the product used by a shared workflow. The trade-off is: Subclass hierarchies can become harder to navigate than injected factories.

## Nearby alternative

Factory Method varies product creation through subclassing. Template Method can vary other steps of a larger algorithm.

## When to simplify

An injected supplier or simple creation function would solve the same problem with fewer classes.

Read the complete implementation in `java/solution/Demo.java`. Compare the TASK area with the starter and trace the exercise checks.
