# Prototype

Create a new object by copying a configured instance.

**Category:** Creational

## Start here

- **3 minutes:** Read this page or Quick_Review.pdf.
- **10 minutes:** Answer Interview_QA.md aloud before revealing the answers.
- **15 minutes:** Follow Practice.md and run the Java exercise.
- **48 seconds:** Watch Pattern_Video.mp4; the clip is silent and captioned.
- **With AI:** Copy one prompt from AI_Prompts.txt, then verify the result.

## Picture it

Copy a worksheet template, then edit your copy without changing everyone else’s template.

## Use it when

A configured object provides a useful starting point for new instances.

## Keep it simpler when

The object owns sockets, threads, or other resources with no meaningful copying contract.

## Contract

Mutable paragraph lists are independent after copying; immutable strings may be shared.

## Nearby idea

Prototype copies state from an instance. Builder constructs from explicit steps; shallow and deep copying are separate choices.

## Interview checkpoint

**Question:** What test exposes a dangerous shallow copy?

**Answer:** Modify nested mutable state in the copy and verify the original stays unchanged.

## Try it

Implement copy so changing the copied paragraph list leaves the original document unchanged.

## Evidence

Append a paragraph to the copy and check original size, copy size, and distinct list identity.

## Trade-off

Deep copying large graphs can be costly and may mishandle cycles or resources.

## Scope

The Java exercise is a small, single-process teaching example. Its scenario can differ from the video to help you recognize the same idea in another setting.

[Open the complete visual guide](README.html) | [Interview questions](Interview_QA.md) | [Practice](Practice.md) | [Solution notes](Solution_Notes.md)
