# Prototype - Interview Questions and Answers

These are original practice questions aligned with skills in published employer guidance. They are not attributed to an actual company interview, endorsed by an employer, or a prediction of interview frequency. See INTERVIEW_GUIDANCE.md at the kit root.

Try each answer aloud in 60-90 seconds. Model answers are examples, not scripts to memorize.

## 1. Explain the idea in plain English, then connect it to code.

**Model answer:** Create a new object by copying a configured instance. Copy a worksheet template, then edit your copy without changing everyone else’s template. In this exercise: Mutable paragraph lists are independent after copying; immutable strings may be shared. Create a new list for the copy. Strings are immutable, so copying their references is sufficient for this specific object graph.

**What to demonstrate:** Explain the collaboration before naming classes.

## 2. What test exposes a dangerous shallow copy?

**Model answer:** Modify nested mutable state in the copy and verify the original stays unchanged.

**What to demonstrate:** Give a concrete example that makes the distinction clear.

## 3. What nearby idea is easy to confuse with this one?

**Model answer:** Prototype copies state from an instance. Builder constructs from explicit steps; shallow and deep copying are separate choices.

**What to demonstrate:** Compare intent and behavior, not just similar-looking diagrams.

## 4. Change request: Implement copy so changing the copied paragraph list leaves the original document unchanged.

**Model answer:** Create a new list for the copy. Strings are immutable, so copying their references is sufficient for this specific object graph.

**What to demonstrate:** Name the exact extension point and identify what remains stable.

## 5. Which tests would convince you that the change is correct?

**Model answer:** Append a paragraph to the copy and check original size, copy size, and distinct list identity.

**What to demonstrate:** State inputs, expected outcomes, and the defect each test would expose.

## 6. What would you clarify before implementing this scenario?

**Model answer:** Ask which nested objects are mutable. Here only the list is mutable; paragraph values are strings.

**What to demonstrate:** Resolve a consequential ambiguity before coding.

## 7. When would you keep the design simpler or choose another approach?

**Model answer:** The object owns sockets, threads, or other resources with no meaningful copying contract. Deep copying large graphs can be costly and may mishandle cycles or resources.

**What to demonstrate:** Explain the cost of the abstraction and the condition that justifies it.

## Self-check

Can you clarify the contract, draw the collaboration, identify the change point, write a test, and explain when a simpler approach wins? Use the original 10-point rubric in the root Interview_Approach.md.
