# Prototype - Solution Notes

## The change

Create a new list for the copy. Strings are immutable, so copying their references is sufficient for this specific object graph.

## Why it works

Mutable paragraph lists are independent after copying; immutable strings may be shared.

## How the checks expose mistakes

Append a paragraph to the copy and check original size, copy size, and distinct list identity.

## What to say in an interview

I chose this design because a configured object provides a useful starting point for new instances. The trade-off is: Deep copying large graphs can be costly and may mishandle cycles or resources.

## Nearby alternative

Prototype copies state from an instance. Builder constructs from explicit steps; shallow and deep copying are separate choices.

## When to simplify

The object owns sockets, threads, or other resources with no meaningful copying contract.

Read the complete implementation in `java/solution/Demo.java`. Compare the TASK area with the starter and trace the exercise checks.
