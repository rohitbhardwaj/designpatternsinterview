import java.util.*;

// Original small teaching example. Java 17+, no external libraries.
// Run: java Demo.java
// Exercise checks: java Demo.java --exercise
// Run each folder separately; every example intentionally uses the class name Demo.
public class Demo {
    static int checks;
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
    }
    static void throwsType(Class<? extends Throwable> type, Runnable action) {
        try { action.run(); }
        catch (Throwable error) {
            if (!type.isInstance(error)) throw new AssertionError("Expected " + type.getSimpleName() + ", got " + error, error);
            checks++; return;
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }
    static class Document {
        final List<String> paragraphs;
        Document(List<String> paragraphs) { this.paragraphs = paragraphs; }
        Document copy() {
            return new Document(new ArrayList<>(paragraphs));
        }
    }

    public static void main(String[] args) {
        Document original = new Document(new ArrayList<>(List.of("Intro")));
        check(original.copy().paragraphs.get(0).equals("Intro"), "copied content");
        if (args.length > 0 && args[0].equals("--exercise")) {
            Document clone = original.copy();
            clone.paragraphs.add("New paragraph");
            check(original.paragraphs.size() == 1, "original unchanged");
            check(clone.paragraphs.size() == 2 && clone.paragraphs != original.paragraphs, "independent mutable list");
        }
        System.out.println("PASS: Prototype (" + checks + " checks)");
    }
}
