import java.util.*;

// Original small teaching example. Java 17+, no external libraries.
// Run: java Demo.java
// Exercise checks: java Demo.java --exercise
// Run each folder separately; every example intentionally uses the class name Demo.
public class Demo {
    static int checks;
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
    }
    static void throwsType(Class<? extends Throwable> type, Runnable action) {
        try { action.run(); }
        catch (Throwable error) {
            if (!type.isInstance(error)) throw new AssertionError("Expected " + type.getSimpleName() + ", got " + error, error);
            checks++; return;
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }
    record Button(String family) {}
    record Checkbox(String family) {}
    interface GUIFactory { Button button(); Checkbox checkbox(); }
    static class WindowsFactory implements GUIFactory {
        public Button button() { return new Button("Windows"); }
        public Checkbox checkbox() { return new Checkbox("Windows"); }
    }
    static GUIFactory macFactory() {
        return new GUIFactory() {
                public Button button() { return new Button("macOS"); }
                public Checkbox checkbox() { return new Checkbox("macOS"); }
            };
    }
    static String screen(GUIFactory f) { return f.button().family() + "/" + f.checkbox().family(); }

    public static void main(String[] args) {
        check(screen(new WindowsFactory()).equals("Windows/Windows"), "existing family");
        if (args.length > 0 && args[0].equals("--exercise")) {
            check(screen(macFactory()).equals("macOS/macOS"), "matching product family");
        }
        System.out.println("PASS: Abstract Factory (" + checks + " checks)");
    }
}
