# Abstract Factory - Interview Questions and Answers

These are original practice questions aligned with skills in published employer guidance. They are not attributed to an actual company interview, endorsed by an employer, or a prediction of interview frequency. See INTERVIEW_GUIDANCE.md at the kit root.

Try each answer aloud in 60-90 seconds. Model answers are examples, not scripts to memorize.

## 1. Explain the idea in plain English, then connect it to code.

**Model answer:** Create a compatible family of related products. Choose a furniture collection and its chair and table arrive in matching styles. In this exercise: A factory produces a Button and Checkbox from the same platform family. Implement both factory methods with matching Mac products; client screen construction remains unchanged.

**What to demonstrate:** Explain the collaboration before naming classes.

## 2. How is this different from creating only one kind of message?

**Model answer:** Abstract Factory emphasizes a family of related product types, not merely one product subtype.

**What to demonstrate:** Give a concrete example that makes the distinction clear.

## 3. What nearby idea is easy to confuse with this one?

**Model answer:** Abstract Factory creates a related family. A factory returning one message subtype does not by itself demonstrate a product family.

**What to demonstrate:** Compare intent and behavior, not just similar-looking diagrams.

## 4. Change request: Implement MacFactory so both products identify as macOS.

**Model answer:** Implement both factory methods with matching Mac products; client screen construction remains unchanged.

**What to demonstrate:** Name the exact extension point and identify what remains stable.

## 5. Which tests would convince you that the change is correct?

**Model answer:** Compare the families returned by both methods. A Windows checkbox in a Mac factory should fail the test.

**What to demonstrate:** State inputs, expected outcomes, and the defect each test would expose.

## 6. What would you clarify before implementing this scenario?

**Model answer:** Ask what makes products compatible and whether product kinds or families change more often. Here platform consistency matters.

**What to demonstrate:** Resolve a consequential ambiguity before coding.

## 7. When would you keep the design simpler or choose another approach?

**Model answer:** There is only one product type and no compatibility requirement. Adding a product kind changes the factory contract and its implementations.

**What to demonstrate:** Explain the cost of the abstraction and the condition that justifies it.

## Self-check

Can you clarify the contract, draw the collaboration, identify the change point, write a test, and explain when a simpler approach wins? Use the original 10-point rubric in the root Interview_Approach.md.
