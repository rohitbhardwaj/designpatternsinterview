# Abstract Factory

Create a compatible family of related products.

**Category:** Creational

## Start here

- **3 minutes:** Read this page or Quick_Review.pdf.
- **10 minutes:** Answer Interview_QA.md aloud before revealing the answers.
- **15 minutes:** Follow Practice.md and run the Java exercise.
- **48 seconds:** Watch Pattern_Video.mp4; the clip is silent and captioned.
- **With AI:** Copy one prompt from AI_Prompts.txt, then verify the result.

## Picture it

Choose a furniture collection and its chair and table arrive in matching styles.

## Use it when

A client needs several related product types that must come from a coherent family.

## Keep it simpler when

There is only one product type and no compatibility requirement.

## Contract

A factory produces a Button and Checkbox from the same platform family.

## Nearby idea

Abstract Factory creates a related family. A factory returning one message subtype does not by itself demonstrate a product family.

## Interview checkpoint

**Question:** How is this different from creating only one kind of message?

**Answer:** Abstract Factory emphasizes a family of related product types, not merely one product subtype.

## Try it

Implement MacFactory so both products identify as macOS.

## Evidence

Compare the families returned by both methods. A Windows checkbox in a Mac factory should fail the test.

## Trade-off

Adding a product kind changes the factory contract and its implementations.

## Scope

The Java exercise is a small, single-process teaching example. Its scenario can differ from the video to help you recognize the same idea in another setting.

[Open the complete visual guide](README.html) | [Interview questions](Interview_QA.md) | [Practice](Practice.md) | [Solution notes](Solution_Notes.md)
