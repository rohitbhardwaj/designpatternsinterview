# Abstract Factory - Solution Notes

## The change

Implement both factory methods with matching Mac products; client screen construction remains unchanged.

## Why it works

A factory produces a Button and Checkbox from the same platform family.

## How the checks expose mistakes

Compare the families returned by both methods. A Windows checkbox in a Mac factory should fail the test.

## What to say in an interview

I chose this design because a client needs several related product types that must come from a coherent family. The trade-off is: Adding a product kind changes the factory contract and its implementations.

## Nearby alternative

Abstract Factory creates a related family. A factory returning one message subtype does not by itself demonstrate a product family.

## When to simplify

There is only one product type and no compatibility requirement.

Read the complete implementation in `java/solution/Demo.java`. Compare the TASK area with the starter and trace the exercise checks.
