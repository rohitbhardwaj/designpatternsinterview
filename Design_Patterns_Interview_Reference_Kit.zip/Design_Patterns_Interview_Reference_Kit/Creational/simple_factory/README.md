# Simple Factory

One creation function selects a concrete product.

**Category:** Creational - additional creation idiom outside the original GoF catalog.

## Start here

- **3 minutes:** Read this page or Quick_Review.pdf.
- **10 minutes:** Answer Interview_QA.md aloud before revealing the answers.
- **15 minutes:** Follow Practice.md and run the Java exercise.
- **48 seconds:** Watch Pattern_Video.mp4; the clip is silent and captioned.
- **With AI:** Copy one prompt from AI_Prompts.txt, then verify the result.

## Picture it

One counter takes your order and selects the correct ready-made product.

## Use it when

Several callers repeat a small, centralized construction choice.

## Keep it simpler when

The function starts choosing unrelated business policies or grows without clear ownership.

## Contract

create returns an Exporter for supported formats and explicitly rejects unknown formats.

## Nearby idea

Simple Factory centralizes selection. Factory Method uses an overridable creation step inside a creator workflow.

## Interview checkpoint

**Question:** Does a Simple Factory automatically satisfy open–closed for new types?

**Answer:** No. A switch-based factory normally changes when the product set changes.

## Try it

Add CSV support to the creation function while preserving PDF behavior and unknown-format rejection.

## Evidence

Check PDF, CSV, and an unsupported XLS request. Do not silently choose a default for unknown input.

## Trade-off

A large factory can become a new concentration of complexity.

## Scope

The Java exercise is a small, single-process teaching example. Its scenario can differ from the video to help you recognize the same idea in another setting.

[Open the complete visual guide](README.html) | [Interview questions](Interview_QA.md) | [Practice](Practice.md) | [Solution notes](Solution_Notes.md)
