# Simple Factory - Solution Notes

## The change

Add a CSV product branch to the central factory. Changing this factory is expected for this simple idiom.

## Why it works

create returns an Exporter for supported formats and explicitly rejects unknown formats.

## How the checks expose mistakes

Check PDF, CSV, and an unsupported XLS request. Do not silently choose a default for unknown input.

## What to say in an interview

I chose this design because several callers repeat a small, centralized construction choice. The trade-off is: A large factory can become a new concentration of complexity.

## Nearby alternative

Simple Factory centralizes selection. Factory Method uses an overridable creation step inside a creator workflow.

## When to simplify

The function starts choosing unrelated business policies or grows without clear ownership.

Read the complete implementation in `java/solution/Demo.java`. Compare the TASK area with the starter and trace the exercise checks.
