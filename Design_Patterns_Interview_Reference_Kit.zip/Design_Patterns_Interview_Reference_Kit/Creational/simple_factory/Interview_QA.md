# Simple Factory - Interview Questions and Answers

These are original practice questions aligned with skills in published employer guidance. They are not attributed to an actual company interview, endorsed by an employer, or a prediction of interview frequency. See INTERVIEW_GUIDANCE.md at the kit root.

Try each answer aloud in 60-90 seconds. Model answers are examples, not scripts to memorize.

## 1. Explain the idea in plain English, then connect it to code.

**Model answer:** One creation function selects a concrete product. One counter takes your order and selects the correct ready-made product. In this exercise: create returns an Exporter for supported formats and explicitly rejects unknown formats. Add a CSV product branch to the central factory. Changing this factory is expected for this simple idiom.

**What to demonstrate:** Explain the collaboration before naming classes.

## 2. Does a Simple Factory automatically satisfy open–closed for new types?

**Model answer:** No. A switch-based factory normally changes when the product set changes.

**What to demonstrate:** Give a concrete example that makes the distinction clear.

## 3. What nearby idea is easy to confuse with this one?

**Model answer:** Simple Factory centralizes selection. Factory Method uses an overridable creation step inside a creator workflow.

**What to demonstrate:** Compare intent and behavior, not just similar-looking diagrams.

## 4. Change request: Add CSV support to the creation function while preserving PDF behavior and unknown-format rejection.

**Model answer:** Add a CSV product branch to the central factory. Changing this factory is expected for this simple idiom.

**What to demonstrate:** Name the exact extension point and identify what remains stable.

## 5. Which tests would convince you that the change is correct?

**Model answer:** Check PDF, CSV, and an unsupported XLS request. Do not silently choose a default for unknown input.

**What to demonstrate:** State inputs, expected outcomes, and the defect each test would expose.

## 6. What would you clarify before implementing this scenario?

**Model answer:** Ask which formats are supported and how invalid input should fail. Only PDF and CSV are supported here.

**What to demonstrate:** Resolve a consequential ambiguity before coding.

## 7. When would you keep the design simpler or choose another approach?

**Model answer:** The function starts choosing unrelated business policies or grows without clear ownership. A large factory can become a new concentration of complexity.

**What to demonstrate:** Explain the cost of the abstraction and the condition that justifies it.

## Self-check

Can you clarify the contract, draw the collaboration, identify the change point, write a test, and explain when a simpler approach wins? Use the original 10-point rubric in the root Interview_Approach.md.
