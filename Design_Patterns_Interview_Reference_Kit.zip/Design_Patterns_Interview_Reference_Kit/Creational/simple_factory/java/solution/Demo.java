import java.util.*;

// Original small teaching example. Java 17+, no external libraries.
// Run: java Demo.java
// Exercise checks: java Demo.java --exercise
// Run each folder separately; every example intentionally uses the class name Demo.
public class Demo {
    static int checks;
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
    }
    static void throwsType(Class<? extends Throwable> type, Runnable action) {
        try { action.run(); }
        catch (Throwable error) {
            if (!type.isInstance(error)) throw new AssertionError("Expected " + type.getSimpleName() + ", got " + error, error);
            checks++; return;
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }
    interface Exporter { String export(); }
    static Exporter create(String format) {
        if ("PDF".equals(format)) return () -> "pdf";
        if ("CSV".equals(format)) return () -> "csv";
            throw new IllegalArgumentException("Unsupported format: " + format);
    }

    public static void main(String[] args) {
        check(create("PDF").export().equals("pdf"), "PDF product");
        throwsType(IllegalArgumentException.class, () -> create("XLS"));
        if (args.length > 0 && args[0].equals("--exercise")) {
            check(create("CSV").export().equals("csv"), "new CSV product");
            throwsType(IllegalArgumentException.class, () -> create("XLS"));
        }
        System.out.println("PASS: Simple Factory (" + checks + " checks)");
    }
}
