# Singleton - Interview Questions and Answers

These are original practice questions aligned with skills in published employer guidance. They are not attributed to an actual company interview, endorsed by an employer, or a prediction of interview frequency. See INTERVIEW_GUIDANCE.md at the kit root.

Try each answer aloud in 60-90 seconds. Model answers are examples, not scripts to memorize.

## 1. Explain the idea in plain English, then connect it to code.

**Model answer:** Control one instance within a defined runtime scope. One shared notice board serves a building; that does not make it the only notice board in the city. In this exercise: The same enum instance is reused within this class-loader scope, and callers cannot mutate its configuration view. Use Map.copyOf to expose a snapshot of immutable string settings. Object identity and state safety are different concerns.

**What to demonstrate:** Explain the collaboration before naming classes.

## 2. Does Singleton mean one instance across a cluster?

**Model answer:** No. Distributed coordination is a separate problem.

**What to demonstrate:** Give a concrete example that makes the distinction clear.

## 3. What nearby idea is easy to confuse with this one?

**Model answer:** Singleton governs instance access. A dependency-injection container can manage one instance without making clients use global access.

**What to demonstrate:** Compare intent and behavior, not just similar-looking diagrams.

## 4. Change request: Return an immutable view of registry settings so callers cannot change the shared configuration.

**Model answer:** Use Map.copyOf to expose a snapshot of immutable string settings. Object identity and state safety are different concerns.

**What to demonstrate:** Name the exact extension point and identify what remains stable.

## 5. Which tests would convince you that the change is correct?

**Model answer:** Check repeated identity and attempt put on the returned map; verify the registry remains unchanged.

**What to demonstrate:** State inputs, expected outcomes, and the defect each test would expose.

## 6. What would you clarify before implementing this scenario?

**Model answer:** Ask what one instance means: class loader, process, or cluster. This example is class-loader scoped and has no distributed coordination.

**What to demonstrate:** Resolve a consequential ambiguity before coding.

## 7. When would you keep the design simpler or choose another approach?

**Model answer:** Global access hides dependencies or tests need independent mutable instances. Shared mutable state introduces concurrency and test-isolation risks.

**What to demonstrate:** Explain the cost of the abstraction and the condition that justifies it.

## Self-check

Can you clarify the contract, draw the collaboration, identify the change point, write a test, and explain when a simpler approach wins? Use the original 10-point rubric in the root Interview_Approach.md.
