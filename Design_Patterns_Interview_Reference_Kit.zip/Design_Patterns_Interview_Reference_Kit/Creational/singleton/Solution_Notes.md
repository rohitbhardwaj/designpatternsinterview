# Singleton - Solution Notes

## The change

Use Map.copyOf to expose a snapshot of immutable string settings. Object identity and state safety are different concerns.

## Why it works

The same enum instance is reused within this class-loader scope, and callers cannot mutate its configuration view.

## How the checks expose mistakes

Check repeated identity and attempt put on the returned map; verify the registry remains unchanged.

## What to say in an interview

I chose this design because exactly one controlled instance is justified within a clearly defined runtime scope. The trade-off is: Shared mutable state introduces concurrency and test-isolation risks.

## Nearby alternative

Singleton governs instance access. A dependency-injection container can manage one instance without making clients use global access.

## When to simplify

Global access hides dependencies or tests need independent mutable instances.

Read the complete implementation in `java/solution/Demo.java`. Compare the TASK area with the starter and trace the exercise checks.
