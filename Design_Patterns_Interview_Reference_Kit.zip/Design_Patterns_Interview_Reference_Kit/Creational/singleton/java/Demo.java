import java.util.*;

// Original small teaching example. Java 17+, no external libraries.
// Run: java Demo.java
// Exercise checks: java Demo.java --exercise
// Run each folder separately; every example intentionally uses the class name Demo.
public class Demo {
    static int checks;
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
    }
    static void throwsType(Class<? extends Throwable> type, Runnable action) {
        try { action.run(); }
        catch (Throwable error) {
            if (!type.isInstance(error)) throw new AssertionError("Expected " + type.getSimpleName() + ", got " + error, error);
            checks++; return;
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }
    enum Registry {
        INSTANCE;
        private final Map<String,String> values = new HashMap<>(Map.of("mode", "safe"));
        Map<String,String> settings() {
            return values; // TASK: protect the shared settings.
        }
    }

    public static void main(String[] args) {
        check(Registry.INSTANCE == Registry.INSTANCE, "same runtime instance");
        check(Registry.INSTANCE.settings().get("mode").equals("safe"), "setting available");
        if (args.length > 0 && args[0].equals("--exercise")) {
            throwsType(UnsupportedOperationException.class, () -> Registry.INSTANCE.settings().put("mode", "unsafe"));
            check(Registry.INSTANCE.settings().get("mode").equals("safe"), "shared state protected");
        }
        System.out.println("PASS: Singleton (" + checks + " checks)");
    }
}
