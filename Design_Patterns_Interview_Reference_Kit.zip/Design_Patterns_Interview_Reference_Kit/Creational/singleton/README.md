# Singleton

Control one instance within a defined runtime scope.

**Category:** Creational

## Start here

- **3 minutes:** Read this page or Quick_Review.pdf.
- **10 minutes:** Answer Interview_QA.md aloud before revealing the answers.
- **15 minutes:** Follow Practice.md and run the Java exercise.
- **48 seconds:** Watch Pattern_Video.mp4; the clip is silent and captioned.
- **With AI:** Copy one prompt from AI_Prompts.txt, then verify the result.

## Picture it

One shared notice board serves a building; that does not make it the only notice board in the city.

## Use it when

Exactly one controlled instance is justified within a clearly defined runtime scope.

## Keep it simpler when

Global access hides dependencies or tests need independent mutable instances.

## Contract

The same enum instance is reused within this class-loader scope, and callers cannot mutate its configuration view.

## Nearby idea

Singleton governs instance access. A dependency-injection container can manage one instance without making clients use global access.

## Interview checkpoint

**Question:** Does Singleton mean one instance across a cluster?

**Answer:** No. Distributed coordination is a separate problem.

## Try it

Return an immutable view of registry settings so callers cannot change the shared configuration.

## Evidence

Check repeated identity and attempt put on the returned map; verify the registry remains unchanged.

## Trade-off

Shared mutable state introduces concurrency and test-isolation risks.

## Scope

The Java exercise is a small, single-process teaching example. Its scenario can differ from the video to help you recognize the same idea in another setting.

[Open the complete visual guide](README.html) | [Interview questions](Interview_QA.md) | [Practice](Practice.md) | [Solution notes](Solution_Notes.md)
