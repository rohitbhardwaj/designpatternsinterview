# Flyweight

Share immutable intrinsic state and supply context separately.

**Category:** Structural

## Start here

- **3 minutes:** Read this page or Quick_Review.pdf.
- **10 minutes:** Answer Interview_QA.md aloud before revealing the answers.
- **15 minutes:** Follow Practice.md and run the Java exercise.
- **48 seconds:** Watch Pattern_Video.mp4; the clip is silent and captioned.
- **With AI:** Copy one prompt from AI_Prompts.txt, then verify the result.

## Picture it

Many printed letters share a font definition, while each letter keeps its own position.

## Use it when

Many objects duplicate substantial immutable state that can be keyed and shared.

## Keep it simpler when

Sharing is tiny, lookup is costly, or per-use mutable state would leak between callers.

## Contract

Equal style keys reuse the same Style identity; character and position stay outside Style.

## Nearby idea

Flyweight shares intrinsic state. Object Pool manages temporary resource ownership; Flyweight instances can be used concurrently when immutable.

## Interview checkpoint

**Question:** Should the shared style store the current glyph’s position?

**Answer:** No. Position belongs to each use and is passed as extrinsic state.

## Try it

Implement StyleFactory.get using a key containing both font and size.

## Evidence

Check identity for equal keys and separation for different sizes. Render two positions using the same style.

## Trade-off

Mutable shared state can cause cross-instance corruption.

## Scope

The Java exercise is a small, single-process teaching example. Its scenario can differ from the video to help you recognize the same idea in another setting.

[Open the complete visual guide](README.html) | [Interview questions](Interview_QA.md) | [Practice](Practice.md) | [Solution notes](Solution_Notes.md)
