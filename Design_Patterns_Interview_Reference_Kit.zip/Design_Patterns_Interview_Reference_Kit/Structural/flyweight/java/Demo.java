import java.util.*;

// Original small teaching example. Java 17+, no external libraries.
// Run: java Demo.java
// Exercise checks: java Demo.java --exercise
// Run each folder separately; every example intentionally uses the class name Demo.
public class Demo {
    static int checks;
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
    }
    static void throwsType(Class<? extends Throwable> type, Runnable action) {
        try { action.run(); }
        catch (Throwable error) {
            if (!type.isInstance(error)) throw new AssertionError("Expected " + type.getSimpleName() + ", got " + error, error);
            checks++; return;
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }
    record Key(String font, int size) {}
    record Style(String font, int size) {
        String draw(char ch, int x) { return ch + "@" + x + ":" + font + ":" + size; }
    }
    static class StyleFactory {
        final Map<Key,Style> cache = new HashMap<>();
        Style get(String font, int size) {
            return new Style(font, size); // TASK: reuse by the complete key.
        }
    }

    public static void main(String[] args) {
        StyleFactory factory = new StyleFactory();
        check(factory.get("Sans", 12).draw('A', 10).equals("A@10:Sans:12"), "per-use position");
        if (args.length > 0 && args[0].equals("--exercise")) {
            Style a = factory.get("Sans", 12), b = factory.get("Sans", 12);
            check(a == b, "equal keys share identity");
            check(a != factory.get("Sans", 14), "size belongs in key");
            check(a.draw('B', 30).equals("B@30:Sans:12"), "context does not leak");
        }
        System.out.println("PASS: Flyweight (" + checks + " checks)");
    }
}
