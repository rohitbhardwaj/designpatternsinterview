# Flyweight - Solution Notes

## The change

Cache an immutable Style by the complete intrinsic key. Do not put x, y, or a current character in shared style state.

## Why it works

Equal style keys reuse the same Style identity; character and position stay outside Style.

## How the checks expose mistakes

Check identity for equal keys and separation for different sizes. Render two positions using the same style.

## What to say in an interview

I chose this design because many objects duplicate substantial immutable state that can be keyed and shared. The trade-off is: Mutable shared state can cause cross-instance corruption.

## Nearby alternative

Flyweight shares intrinsic state. Object Pool manages temporary resource ownership; Flyweight instances can be used concurrently when immutable.

## When to simplify

Sharing is tiny, lookup is costly, or per-use mutable state would leak between callers.

Read the complete implementation in `java/solution/Demo.java`. Compare the TASK area with the starter and trace the exercise checks.
