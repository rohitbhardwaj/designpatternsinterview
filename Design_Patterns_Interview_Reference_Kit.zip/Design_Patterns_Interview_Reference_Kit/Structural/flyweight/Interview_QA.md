# Flyweight - Interview Questions and Answers

These are original practice questions aligned with skills in published employer guidance. They are not attributed to an actual company interview, endorsed by an employer, or a prediction of interview frequency. See INTERVIEW_GUIDANCE.md at the kit root.

Try each answer aloud in 60-90 seconds. Model answers are examples, not scripts to memorize.

## 1. Explain the idea in plain English, then connect it to code.

**Model answer:** Share immutable intrinsic state and supply context separately. Many printed letters share a font definition, while each letter keeps its own position. In this exercise: Equal style keys reuse the same Style identity; character and position stay outside Style. Cache an immutable Style by the complete intrinsic key. Do not put x, y, or a current character in shared style state.

**What to demonstrate:** Explain the collaboration before naming classes.

## 2. Should the shared style store the current glyph’s position?

**Model answer:** No. Position belongs to each use and is passed as extrinsic state.

**What to demonstrate:** Give a concrete example that makes the distinction clear.

## 3. What nearby idea is easy to confuse with this one?

**Model answer:** Flyweight shares intrinsic state. Object Pool manages temporary resource ownership; Flyweight instances can be used concurrently when immutable.

**What to demonstrate:** Compare intent and behavior, not just similar-looking diagrams.

## 4. Change request: Implement StyleFactory.get using a key containing both font and size.

**Model answer:** Cache an immutable Style by the complete intrinsic key. Do not put x, y, or a current character in shared style state.

**What to demonstrate:** Name the exact extension point and identify what remains stable.

## 5. Which tests would convince you that the change is correct?

**Model answer:** Check identity for equal keys and separation for different sizes. Render two positions using the same style.

**What to demonstrate:** State inputs, expected outcomes, and the defect each test would expose.

## 6. What would you clarify before implementing this scenario?

**Model answer:** Ask which fields are intrinsic and whether the cache needs bounds or concurrency. This example uses a small single-threaded cache.

**What to demonstrate:** Resolve a consequential ambiguity before coding.

## 7. When would you keep the design simpler or choose another approach?

**Model answer:** Sharing is tiny, lookup is costly, or per-use mutable state would leak between callers. Mutable shared state can cause cross-instance corruption.

**What to demonstrate:** Explain the cost of the abstraction and the condition that justifies it.

## Self-check

Can you clarify the contract, draw the collaboration, identify the change point, write a test, and explain when a simpler approach wins? Use the original 10-point rubric in the root Interview_Approach.md.
