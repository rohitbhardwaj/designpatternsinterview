import java.util.*;

// Original small teaching example. Java 17+, no external libraries.
// Run: java Demo.java
// Exercise checks: java Demo.java --exercise
// Run each folder separately; every example intentionally uses the class name Demo.
public class Demo {
    static int checks;
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
    }
    static void throwsType(Class<? extends Throwable> type, Runnable action) {
        try { action.run(); }
        catch (Throwable error) {
            if (!type.isInstance(error)) throw new AssertionError("Expected " + type.getSimpleName() + ", got " + error, error);
            checks++; return;
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }
    interface Format { String render(String content); }
    abstract static class Report {
        final Format format;
        Report(Format format) { this.format = format; }
        abstract String content();
        String export() { return format.render(content()); }
    }
    static class SalesReport extends Report { SalesReport(Format f) { super(f); } String content() { return "sales"; } }
    static class StockReport extends Report { StockReport(Format f) { super(f); } String content() { return "stock"; } }
    static Format jsonFormat() {
        return content -> "{\"report\":\"" + content + "\"}"; // Fixed teaching values only; use a JSON library for arbitrary text.
    }

    public static void main(String[] args) {
        Format text = content -> content;
        check(new SalesReport(text).export().equals("sales"), "sales/text");
        check(new StockReport(text).export().equals("stock"), "stock/text");
        if (args.length > 0 && args[0].equals("--exercise")) {
            check(new SalesReport(jsonFormat()).export().equals("{\"report\":\"sales\"}"), "sales/json");
            check(new StockReport(jsonFormat()).export().equals("{\"report\":\"stock\"}"), "stock/json");
        }
        System.out.println("PASS: Bridge (" + checks + " checks)");
    }
}
