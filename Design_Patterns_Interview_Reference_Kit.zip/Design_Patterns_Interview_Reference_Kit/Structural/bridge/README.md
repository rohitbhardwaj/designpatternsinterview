# Bridge

Let two dimensions vary independently through composition.

**Category:** Structural

## Start here

- **3 minutes:** Read this page or Quick_Review.pdf.
- **10 minutes:** Answer Interview_QA.md aloud before revealing the answers.
- **15 minutes:** Follow Practice.md and run the Java exercise.
- **48 seconds:** Watch Pattern_Video.mp4; the clip is silent and captioned.
- **With AI:** Copy one prompt from AI_Prompts.txt, then verify the result.

## Picture it

A remote-control design can vary independently from the device it operates.

## Use it when

Two real design dimensions must evolve without a subclass for every combination.

## Keep it simpler when

Only one dimension varies, or the proposed combinations make no sense in the domain.

## Contract

Report type and output format vary independently; adding a format does not edit report subclasses.

## Nearby idea

Bridge is planned independent variation through composition. Adapter translates an already-existing mismatch.

## Interview checkpoint

**Question:** Which two dimensions vary independently in the report exercise?

**Answer:** Report content (sales or stock) and output format (text or JSON).

## Try it

Implement a JSON Format and use it with both SalesReport and StockReport.

## Evidence

Run all four combinations: sales/text, stock/text, sales/JSON, stock/JSON.

## Trade-off

An artificial second dimension adds indirection without useful flexibility.

## Scope

The Java exercise is a small, single-process teaching example. Its scenario can differ from the video to help you recognize the same idea in another setting.

[Open the complete visual guide](README.html) | [Interview questions](Interview_QA.md) | [Practice](Practice.md) | [Solution notes](Solution_Notes.md)
