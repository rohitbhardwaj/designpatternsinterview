# Bridge - Interview Questions and Answers

These are original practice questions aligned with skills in published employer guidance. They are not attributed to an actual company interview, endorsed by an employer, or a prediction of interview frequency. See INTERVIEW_GUIDANCE.md at the kit root.

Try each answer aloud in 60-90 seconds. Model answers are examples, not scripts to memorize.

## 1. Explain the idea in plain English, then connect it to code.

**Model answer:** Let two dimensions vary independently through composition. A remote-control design can vary independently from the device it operates. In this exercise: Report type and output format vary independently; adding a format does not edit report subclasses. Supply one new Format implementation to both report types. Keep report-specific content in the report classes.

**What to demonstrate:** Explain the collaboration before naming classes.

## 2. Which two dimensions vary independently in the report exercise?

**Model answer:** Report content (sales or stock) and output format (text or JSON).

**What to demonstrate:** Give a concrete example that makes the distinction clear.

## 3. What nearby idea is easy to confuse with this one?

**Model answer:** Bridge is planned independent variation through composition. Adapter translates an already-existing mismatch.

**What to demonstrate:** Compare intent and behavior, not just similar-looking diagrams.

## 4. Change request: Implement a JSON Format and use it with both SalesReport and StockReport.

**Model answer:** Supply one new Format implementation to both report types. Keep report-specific content in the report classes.

**What to demonstrate:** Name the exact extension point and identify what remains stable.

## 5. Which tests would convince you that the change is correct?

**Model answer:** Run all four combinations: sales/text, stock/text, sales/JSON, stock/JSON.

**What to demonstrate:** State inputs, expected outcomes, and the defect each test would expose.

## 6. What would you clarify before implementing this scenario?

**Model answer:** Ask which dimensions genuinely vary. Here report content and rendering format are independent; the format handles fixed teaching strings.

**What to demonstrate:** Resolve a consequential ambiguity before coding.

## 7. When would you keep the design simpler or choose another approach?

**Model answer:** Only one dimension varies, or the proposed combinations make no sense in the domain. An artificial second dimension adds indirection without useful flexibility.

**What to demonstrate:** Explain the cost of the abstraction and the condition that justifies it.

## Self-check

Can you clarify the contract, draw the collaboration, identify the change point, write a test, and explain when a simpler approach wins? Use the original 10-point rubric in the root Interview_Approach.md.
