# Bridge - Solution Notes

## The change

Supply one new Format implementation to both report types. Keep report-specific content in the report classes.

## Why it works

Report type and output format vary independently; adding a format does not edit report subclasses.

## How the checks expose mistakes

Run all four combinations: sales/text, stock/text, sales/JSON, stock/JSON.

## What to say in an interview

I chose this design because two real design dimensions must evolve without a subclass for every combination. The trade-off is: An artificial second dimension adds indirection without useful flexibility.

## Nearby alternative

Bridge is planned independent variation through composition. Adapter translates an already-existing mismatch.

## When to simplify

Only one dimension varies, or the proposed combinations make no sense in the domain.

Read the complete implementation in `java/solution/Demo.java`. Compare the TASK area with the starter and trace the exercise checks.
