# Facade - Solution Notes

## The change

Call reserve, pay, and ship in order. Let the error propagate. Compensation for the reservation is a separate design decision.

## Why it works

Checkout reserves, pays, then ships; it stops if payment fails and does not promise rollback.

## How the checks expose mistakes

Record the happy-path sequence, then make pay fail and verify ship is never called.

## What to say in an interview

I chose this design because callers repeat the same coordination across a subsystem. The trade-off is: An oversized facade can become a God class.

## Nearby alternative

Facade simplifies subsystem access. Adapter translates an interface; Facade may expose a new use-case-oriented interface.

## When to simplify

The facade starts owning every business policy or hides essential failure behavior.

Read the complete implementation in `java/solution/Demo.java`. Compare the TASK area with the starter and trace the exercise checks.
