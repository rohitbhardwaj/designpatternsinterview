import java.util.*;

// Original small teaching example. Java 17+, no external libraries.
// Run: java Demo.java
// Exercise checks: java Demo.java --exercise
// Run each folder separately; every example intentionally uses the class name Demo.
public class Demo {
    static int checks;
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
    }
    static void throwsType(Class<? extends Throwable> type, Runnable action) {
        try { action.run(); }
        catch (Throwable error) {
            if (!type.isInstance(error)) throw new AssertionError("Expected " + type.getSimpleName() + ", got " + error, error);
            checks++; return;
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }
    record CheckoutFacade(Runnable reserve, Runnable pay, Runnable ship) {
        void placeOrder() {
            reserve.run(); pay.run(); ship.run();
        }
    }

    public static void main(String[] args) {
        List<String> events = new ArrayList<>();
        Runnable reserve = () -> events.add("reserve");
        reserve.run(); check(events.equals(List.of("reserve")), "subsystem callable");
        if (args.length > 0 && args[0].equals("--exercise")) {
            List<String> success = new ArrayList<>();
            new CheckoutFacade(() -> success.add("reserve"), () -> success.add("pay"), () -> success.add("ship")).placeOrder();
            check(success.equals(List.of("reserve", "pay", "ship")), "sequence");
            List<String> failure = new ArrayList<>();
            throwsType(IllegalStateException.class, () -> new CheckoutFacade(() -> failure.add("reserve"), () -> { throw new IllegalStateException("payment failed"); }, () -> failure.add("ship")).placeOrder());
            check(failure.equals(List.of("reserve")), "shipping skipped after failure");
        }
        System.out.println("PASS: Facade (" + checks + " checks)");
    }
}
