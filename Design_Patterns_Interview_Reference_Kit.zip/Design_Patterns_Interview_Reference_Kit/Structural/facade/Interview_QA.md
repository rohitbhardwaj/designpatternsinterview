# Facade - Interview Questions and Answers

These are original practice questions aligned with skills in published employer guidance. They are not attributed to an actual company interview, endorsed by an employer, or a prediction of interview frequency. See INTERVIEW_GUIDANCE.md at the kit root.

Try each answer aloud in 60-90 seconds. Model answers are examples, not scripts to memorize.

## 1. Explain the idea in plain English, then connect it to code.

**Model answer:** Offer a focused entry point to a complex subsystem. A hotel concierge gives you one entry point to several hotel services. In this exercise: Checkout reserves, pays, then ships; it stops if payment fails and does not promise rollback. Call reserve, pay, and ship in order. Let the error propagate. Compensation for the reservation is a separate design decision.

**What to demonstrate:** Explain the collaboration before naming classes.

## 2. Does a facade make its remote calls atomic?

**Model answer:** No. Transaction and recovery behavior need separate design.

**What to demonstrate:** Give a concrete example that makes the distinction clear.

## 3. What nearby idea is easy to confuse with this one?

**Model answer:** Facade simplifies subsystem access. Adapter translates an interface; Facade may expose a new use-case-oriented interface.

**What to demonstrate:** Compare intent and behavior, not just similar-looking diagrams.

## 4. Change request: Implement placeOrder in the documented sequence without swallowing payment failure.

**Model answer:** Call reserve, pay, and ship in order. Let the error propagate. Compensation for the reservation is a separate design decision.

**What to demonstrate:** Name the exact extension point and identify what remains stable.

## 5. Which tests would convince you that the change is correct?

**Model answer:** Record the happy-path sequence, then make pay fail and verify ship is never called.

**What to demonstrate:** State inputs, expected outcomes, and the defect each test would expose.

## 6. What would you clarify before implementing this scenario?

**Model answer:** Ask what partial failure means. Here the reservation remains after failed payment; the exercise demonstrates sequencing, not a distributed transaction.

**What to demonstrate:** Resolve a consequential ambiguity before coding.

## 7. When would you keep the design simpler or choose another approach?

**Model answer:** The facade starts owning every business policy or hides essential failure behavior. An oversized facade can become a God class.

**What to demonstrate:** Explain the cost of the abstraction and the condition that justifies it.

## Self-check

Can you clarify the contract, draw the collaboration, identify the change point, write a test, and explain when a simpler approach wins? Use the original 10-point rubric in the root Interview_Approach.md.
