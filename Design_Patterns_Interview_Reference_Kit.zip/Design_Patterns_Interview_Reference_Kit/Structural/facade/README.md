# Facade

Offer a focused entry point to a complex subsystem.

**Category:** Structural

## Start here

- **3 minutes:** Read this page or Quick_Review.pdf.
- **10 minutes:** Answer Interview_QA.md aloud before revealing the answers.
- **15 minutes:** Follow Practice.md and run the Java exercise.
- **48 seconds:** Watch Pattern_Video.mp4; the clip is silent and captioned.
- **With AI:** Copy one prompt from AI_Prompts.txt, then verify the result.

## Picture it

A hotel concierge gives you one entry point to several hotel services.

## Use it when

Callers repeat the same coordination across a subsystem.

## Keep it simpler when

The facade starts owning every business policy or hides essential failure behavior.

## Contract

Checkout reserves, pays, then ships; it stops if payment fails and does not promise rollback.

## Nearby idea

Facade simplifies subsystem access. Adapter translates an interface; Facade may expose a new use-case-oriented interface.

## Interview checkpoint

**Question:** Does a facade make its remote calls atomic?

**Answer:** No. Transaction and recovery behavior need separate design.

## Try it

Implement placeOrder in the documented sequence without swallowing payment failure.

## Evidence

Record the happy-path sequence, then make pay fail and verify ship is never called.

## Trade-off

An oversized facade can become a God class.

## Scope

The Java exercise is a small, single-process teaching example. Its scenario can differ from the video to help you recognize the same idea in another setting.

[Open the complete visual guide](README.html) | [Interview questions](Interview_QA.md) | [Practice](Practice.md) | [Solution notes](Solution_Notes.md)
