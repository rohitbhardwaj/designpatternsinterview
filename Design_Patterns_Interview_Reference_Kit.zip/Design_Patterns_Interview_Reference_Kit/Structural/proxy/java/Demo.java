import java.util.*;

// Original small teaching example. Java 17+, no external libraries.
// Run: java Demo.java
// Exercise checks: java Demo.java --exercise
// Run each folder separately; every example intentionally uses the class name Demo.
public class Demo {
    static int checks;
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
    }
    static void throwsType(Class<? extends Throwable> type, Runnable action) {
        try { action.run(); }
        catch (Throwable error) {
            if (!type.isInstance(error)) throw new AssertionError("Expected " + type.getSimpleName() + ", got " + error, error);
            checks++; return;
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }
    interface Document { String read(); }
    record SecuredDocument(boolean allowed, Document real) implements Document {
        public String read() {
            return real.read(); // TASK: enforce authorization before delegation.
        }
    }

    public static void main(String[] args) {
        check(new SecuredDocument(true, () -> "content").read().equals("content"), "allowed access");
        if (args.length > 0 && args[0].equals("--exercise")) {
            int[] reads = {0};
            Document real = () -> { reads[0]++; return "content"; };
            throwsType(SecurityException.class, () -> new SecuredDocument(false, real).read());
            check(reads[0] == 0, "denied request did not reach target");
            new SecuredDocument(true, real).read();
            check(reads[0] == 1, "one allowed call");
        }
        System.out.println("PASS: Proxy (" + checks + " checks)");
    }
}
