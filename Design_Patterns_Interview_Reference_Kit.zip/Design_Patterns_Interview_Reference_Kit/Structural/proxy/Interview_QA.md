# Proxy - Interview Questions and Answers

These are original practice questions aligned with skills in published employer guidance. They are not attributed to an actual company interview, endorsed by an employer, or a prediction of interview frequency. See INTERVIEW_GUIDANCE.md at the kit root.

Try each answer aloud in 60-90 seconds. Model answers are examples, not scripts to memorize.

## 1. Explain the idea in plain English, then connect it to code.

**Model answer:** Control access to an object through a substitute. A receptionist checks access before allowing a visitor through to an office. In this exercise: A denied read throws before the real document is touched; an allowed read delegates once. Reject denied access immediately, then call the wrapped Document for allowed access.

**What to demonstrate:** Explain the collaboration before naming classes.

## 2. What would bypass this protection proxy?

**Model answer:** A caller obtaining and invoking the real protected object directly.

**What to demonstrate:** Give a concrete example that makes the distinction clear.

## 3. What nearby idea is easy to confuse with this one?

**Model answer:** Proxy controls access or lifecycle. Decorator adds responsibilities; neither name alone establishes a security guarantee.

**What to demonstrate:** Compare intent and behavior, not just similar-looking diagrams.

## 4. Change request: Implement SecuredDocument.read with the authorization check before delegation.

**Model answer:** Reject denied access immediately, then call the wrapped Document for allowed access.

**What to demonstrate:** Name the exact extension point and identify what remains stable.

## 5. Which tests would convince you that the change is correct?

**Model answer:** Count real reads. The denied case must leave the counter at zero, and the allowed case must increment it once.

**What to demonstrate:** State inputs, expected outcomes, and the defect each test would expose.

## 6. What would you clarify before implementing this scenario?

**Model answer:** Ask where authorization is enforced and whether the target can be bypassed. This local teaching example assumes callers receive only the proxy.

**What to demonstrate:** Resolve a consequential ambiguity before coding.

## 7. When would you keep the design simpler or choose another approach?

**Model answer:** Callers can freely bypass the wrapper to reach the protected target. Local wrappers do not replace authentication and enforcement at real trust boundaries.

**What to demonstrate:** Explain the cost of the abstraction and the condition that justifies it.

## Self-check

Can you clarify the contract, draw the collaboration, identify the change point, write a test, and explain when a simpler approach wins? Use the original 10-point rubric in the root Interview_Approach.md.
