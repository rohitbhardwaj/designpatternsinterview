# Proxy - Solution Notes

## The change

Reject denied access immediately, then call the wrapped Document for allowed access.

## Why it works

A denied read throws before the real document is touched; an allowed read delegates once.

## How the checks expose mistakes

Count real reads. The denied case must leave the counter at zero, and the allowed case must increment it once.

## What to say in an interview

I chose this design because access, lazy initialization, or another control boundary should surround a target object. The trade-off is: Local wrappers do not replace authentication and enforcement at real trust boundaries.

## Nearby alternative

Proxy controls access or lifecycle. Decorator adds responsibilities; neither name alone establishes a security guarantee.

## When to simplify

Callers can freely bypass the wrapper to reach the protected target.

Read the complete implementation in `java/solution/Demo.java`. Compare the TASK area with the starter and trace the exercise checks.
