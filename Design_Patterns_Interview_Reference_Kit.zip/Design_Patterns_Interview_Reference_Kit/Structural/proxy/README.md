# Proxy

Control access to an object through a substitute.

**Category:** Structural

## Start here

- **3 minutes:** Read this page or Quick_Review.pdf.
- **10 minutes:** Answer Interview_QA.md aloud before revealing the answers.
- **15 minutes:** Follow Practice.md and run the Java exercise.
- **48 seconds:** Watch Pattern_Video.mp4; the clip is silent and captioned.
- **With AI:** Copy one prompt from AI_Prompts.txt, then verify the result.

## Picture it

A receptionist checks access before allowing a visitor through to an office.

## Use it when

Access, lazy initialization, or another control boundary should surround a target object.

## Keep it simpler when

Callers can freely bypass the wrapper to reach the protected target.

## Contract

A denied read throws before the real document is touched; an allowed read delegates once.

## Nearby idea

Proxy controls access or lifecycle. Decorator adds responsibilities; neither name alone establishes a security guarantee.

## Interview checkpoint

**Question:** What would bypass this protection proxy?

**Answer:** A caller obtaining and invoking the real protected object directly.

## Try it

Implement SecuredDocument.read with the authorization check before delegation.

## Evidence

Count real reads. The denied case must leave the counter at zero, and the allowed case must increment it once.

## Trade-off

Local wrappers do not replace authentication and enforcement at real trust boundaries.

## Scope

The Java exercise is a small, single-process teaching example. Its scenario can differ from the video to help you recognize the same idea in another setting.

[Open the complete visual guide](README.html) | [Interview questions](Interview_QA.md) | [Practice](Practice.md) | [Solution notes](Solution_Notes.md)
