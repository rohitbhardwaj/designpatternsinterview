# Composite - Solution Notes

## The change

Ask every child for size and sum the results. A child directory handles its own recursion.

## Why it works

Directory size is the sum of its child sizes; an empty directory has size zero.

## How the checks expose mistakes

Test an empty directory and a nested directory containing files of 2 and 8 units; the root total is 10.

## What to say in an interview

I chose this design because a tree contains leaves and groups with a useful shared operation. The trade-off is: Uniform interfaces can become dishonest if leaves must fake unsupported operations.

## Nearby alternative

Composite models part-whole structure. Decorator wraps a component to add behavior rather than aggregate a child collection.

## When to simplify

Leaves would need to fake group-only operations, or the structure is actually an unrestricted graph.

Read the complete implementation in `java/solution/Demo.java`. Compare the TASK area with the starter and trace the exercise checks.
