# Composite

Treat a leaf and a group through a shared operation.

**Category:** Structural

## Start here

- **3 minutes:** Read this page or Quick_Review.pdf.
- **10 minutes:** Answer Interview_QA.md aloud before revealing the answers.
- **15 minutes:** Follow Practice.md and run the Java exercise.
- **48 seconds:** Watch Pattern_Video.mp4; the clip is silent and captioned.
- **With AI:** Copy one prompt from AI_Prompts.txt, then verify the result.

## Picture it

A folder can hold files and more folders, and all can answer a size question.

## Use it when

A tree contains leaves and groups with a useful shared operation.

## Keep it simpler when

Leaves would need to fake group-only operations, or the structure is actually an unrestricted graph.

## Contract

Directory size is the sum of its child sizes; an empty directory has size zero.

## Nearby idea

Composite models part-whole structure. Decorator wraps a component to add behavior rather than aggregate a child collection.

## Interview checkpoint

**Question:** Must a leaf support addChild()?

**Answer:** No. A safe design can keep child management on the composite type.

## Try it

Implement Directory.size recursively through the Component contract.

## Evidence

Test an empty directory and a nested directory containing files of 2 and 8 units; the root total is 10.

## Trade-off

Uniform interfaces can become dishonest if leaves must fake unsupported operations.

## Scope

The Java exercise is a small, single-process teaching example. Its scenario can differ from the video to help you recognize the same idea in another setting.

[Open the complete visual guide](README.html) | [Interview questions](Interview_QA.md) | [Practice](Practice.md) | [Solution notes](Solution_Notes.md)
