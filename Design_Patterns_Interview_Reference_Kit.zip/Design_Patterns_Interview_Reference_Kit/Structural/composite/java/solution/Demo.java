import java.util.*;

// Original small teaching example. Java 17+, no external libraries.
// Run: java Demo.java
// Exercise checks: java Demo.java --exercise
// Run each folder separately; every example intentionally uses the class name Demo.
public class Demo {
    static int checks;
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
    }
    static void throwsType(Class<? extends Throwable> type, Runnable action) {
        try { action.run(); }
        catch (Throwable error) {
            if (!type.isInstance(error)) throw new AssertionError("Expected " + type.getSimpleName() + ", got " + error, error);
            checks++; return;
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }
    interface Component { long size(); }
    record FileLeaf(long size) implements Component {}
    record Directory(List<Component> children) implements Component {
        Directory { children = List.copyOf(children); }
        public long size() {
            long total = 0;
                    for (Component child : children) total += child.size();
                    return total;
        }
    }

    public static void main(String[] args) {
        check(new FileLeaf(2).size() == 2, "leaf size");
        if (args.length > 0 && args[0].equals("--exercise")) {
            check(new Directory(List.of()).size() == 0, "empty directory");
            Component root = new Directory(List.of(new FileLeaf(2), new Directory(List.of(new FileLeaf(8)))));
            check(root.size() == 10, "nested aggregation");
        }
        System.out.println("PASS: Composite (" + checks + " checks)");
    }
}
