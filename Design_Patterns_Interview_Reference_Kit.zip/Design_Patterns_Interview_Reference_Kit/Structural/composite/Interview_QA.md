# Composite - Interview Questions and Answers

These are original practice questions aligned with skills in published employer guidance. They are not attributed to an actual company interview, endorsed by an employer, or a prediction of interview frequency. See INTERVIEW_GUIDANCE.md at the kit root.

Try each answer aloud in 60-90 seconds. Model answers are examples, not scripts to memorize.

## 1. Explain the idea in plain English, then connect it to code.

**Model answer:** Treat a leaf and a group through a shared operation. A folder can hold files and more folders, and all can answer a size question. In this exercise: Directory size is the sum of its child sizes; an empty directory has size zero. Ask every child for size and sum the results. A child directory handles its own recursion.

**What to demonstrate:** Explain the collaboration before naming classes.

## 2. Must a leaf support addChild()?

**Model answer:** No. A safe design can keep child management on the composite type.

**What to demonstrate:** Give a concrete example that makes the distinction clear.

## 3. What nearby idea is easy to confuse with this one?

**Model answer:** Composite models part-whole structure. Decorator wraps a component to add behavior rather than aggregate a child collection.

**What to demonstrate:** Compare intent and behavior, not just similar-looking diagrams.

## 4. Change request: Implement Directory.size recursively through the Component contract.

**Model answer:** Ask every child for size and sum the results. A child directory handles its own recursion.

**What to demonstrate:** Name the exact extension point and identify what remains stable.

## 5. Which tests would convince you that the change is correct?

**Model answer:** Test an empty directory and a nested directory containing files of 2 and 8 units; the root total is 10.

**What to demonstrate:** State inputs, expected outcomes, and the defect each test would expose.

## 6. What would you clarify before implementing this scenario?

**Model answer:** Ask whether cycles and shared children are allowed. This immutable teaching model is a tree; production mutable graphs need additional rules.

**What to demonstrate:** Resolve a consequential ambiguity before coding.

## 7. When would you keep the design simpler or choose another approach?

**Model answer:** Leaves would need to fake group-only operations, or the structure is actually an unrestricted graph. Uniform interfaces can become dishonest if leaves must fake unsupported operations.

**What to demonstrate:** Explain the cost of the abstraction and the condition that justifies it.

## Self-check

Can you clarify the contract, draw the collaboration, identify the change point, write a test, and explain when a simpler approach wins? Use the original 10-point rubric in the root Interview_Approach.md.
