# Decorator

Wrap the same contract to add behavior in layers.

**Category:** Structural

## Start here

- **3 minutes:** Read this page or Quick_Review.pdf.
- **10 minutes:** Answer Interview_QA.md aloud before revealing the answers.
- **15 minutes:** Follow Practice.md and run the Java exercise.
- **48 seconds:** Watch Pattern_Video.mp4; the clip is silent and captioned.
- **With AI:** Copy one prompt from AI_Prompts.txt, then verify the result.

## Picture it

Layers of clothing add capabilities while the person inside remains the same person.

## Use it when

Optional responsibilities need to be combined around the same component contract.

## Keep it simpler when

Wrapper order is unclear or the extra behavior breaks the promised contract.

## Contract

Each wrapper delegates once, returns the core result, and records completion in reverse order on success.

## Nearby idea

Decorator adds responsibilities. Proxy controls access or lifecycle; similar delegation structures have different intent.

## Interview checkpoint

**Question:** What makes a wrapper a Decorator rather than just a helper?

**Answer:** It implements the component contract and delegates to another component through that contract.

## Try it

Implement Logging.run so nested wrappers record entry and successful exit around the core call.

## Evidence

Check the exact event order and returned value. A wrapper that forgets delegation or calls twice fails.

## Trade-off

Wrapper stacks can hide order-dependent behavior and repeated side effects.

## Scope

The Java exercise is a small, single-process teaching example. Its scenario can differ from the video to help you recognize the same idea in another setting.

[Open the complete visual guide](README.html) | [Interview questions](Interview_QA.md) | [Practice](Practice.md) | [Solution notes](Solution_Notes.md)
