# Decorator - Interview Questions and Answers

These are original practice questions aligned with skills in published employer guidance. They are not attributed to an actual company interview, endorsed by an employer, or a prediction of interview frequency. See INTERVIEW_GUIDANCE.md at the kit root.

Try each answer aloud in 60-90 seconds. Model answers are examples, not scripts to memorize.

## 1. Explain the idea in plain English, then connect it to code.

**Model answer:** Wrap the same contract to add behavior in layers. Layers of clothing add capabilities while the person inside remains the same person. In this exercise: Each wrapper delegates once, returns the core result, and records completion in reverse order on success. Append the entry event, call the wrapped operation once, append exit, and return the original result.

**What to demonstrate:** Explain the collaboration before naming classes.

## 2. What makes a wrapper a Decorator rather than just a helper?

**Model answer:** It implements the component contract and delegates to another component through that contract.

**What to demonstrate:** Give a concrete example that makes the distinction clear.

## 3. What nearby idea is easy to confuse with this one?

**Model answer:** Decorator adds responsibilities. Proxy controls access or lifecycle; similar delegation structures have different intent.

**What to demonstrate:** Compare intent and behavior, not just similar-looking diagrams.

## 4. Change request: Implement Logging.run so nested wrappers record entry and successful exit around the core call.

**Model answer:** Append the entry event, call the wrapped operation once, append exit, and return the original result.

**What to demonstrate:** Name the exact extension point and identify what remains stable.

## 5. Which tests would convince you that the change is correct?

**Model answer:** Check the exact event order and returned value. A wrapper that forgets delegation or calls twice fails.

**What to demonstrate:** State inputs, expected outcomes, and the defect each test would expose.

## 6. What would you clarify before implementing this scenario?

**Model answer:** Ask whether exit means success or finally-completion. In this exercise it means success; exceptions propagate without an exit event.

**What to demonstrate:** Resolve a consequential ambiguity before coding.

## 7. When would you keep the design simpler or choose another approach?

**Model answer:** Wrapper order is unclear or the extra behavior breaks the promised contract. Wrapper stacks can hide order-dependent behavior and repeated side effects.

**What to demonstrate:** Explain the cost of the abstraction and the condition that justifies it.

## Self-check

Can you clarify the contract, draw the collaboration, identify the change point, write a test, and explain when a simpler approach wins? Use the original 10-point rubric in the root Interview_Approach.md.
