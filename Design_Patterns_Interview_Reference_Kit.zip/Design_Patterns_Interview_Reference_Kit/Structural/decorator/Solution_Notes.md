# Decorator - Solution Notes

## The change

Append the entry event, call the wrapped operation once, append exit, and return the original result.

## Why it works

Each wrapper delegates once, returns the core result, and records completion in reverse order on success.

## How the checks expose mistakes

Check the exact event order and returned value. A wrapper that forgets delegation or calls twice fails.

## What to say in an interview

I chose this design because optional responsibilities need to be combined around the same component contract. The trade-off is: Wrapper stacks can hide order-dependent behavior and repeated side effects.

## Nearby alternative

Decorator adds responsibilities. Proxy controls access or lifecycle; similar delegation structures have different intent.

## When to simplify

Wrapper order is unclear or the extra behavior breaks the promised contract.

Read the complete implementation in `java/solution/Demo.java`. Compare the TASK area with the starter and trace the exercise checks.
