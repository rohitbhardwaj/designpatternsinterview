import java.util.*;

// Original small teaching example. Java 17+, no external libraries.
// Run: java Demo.java
// Exercise checks: java Demo.java --exercise
// Run each folder separately; every example intentionally uses the class name Demo.
public class Demo {
    static int checks;
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
    }
    static void throwsType(Class<? extends Throwable> type, Runnable action) {
        try { action.run(); }
        catch (Throwable error) {
            if (!type.isInstance(error)) throw new AssertionError("Expected " + type.getSimpleName() + ", got " + error, error);
            checks++; return;
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }
    interface Operation { String run(); }
    record Logging(String name, Operation next, List<String> events) implements Operation {
        public String run() {
            throw new UnsupportedOperationException("Implement Logging.run");
        }
    }

    public static void main(String[] args) {
        Operation core = () -> "ok";
        check(core.run().equals("ok"), "core contract");
        if (args.length > 0 && args[0].equals("--exercise")) {
            List<String> events = new ArrayList<>();
            Operation coreWithTrace = () -> { events.add("core"); return "ok"; };
            Operation wrapped = new Logging("A", new Logging("B", coreWithTrace, events), events);
            check(wrapped.run().equals("ok"), "same result");
            check(events.equals(List.of("A:in", "B:in", "core", "B:out", "A:out")), "wrapper order");
        }
        System.out.println("PASS: Decorator (" + checks + " checks)");
    }
}
