# Adapter - Interview Questions and Answers

These are original practice questions aligned with skills in published employer guidance. They are not attributed to an actual company interview, endorsed by an employer, or a prediction of interview frequency. See INTERVIEW_GUIDANCE.md at the kit root.

Try each answer aloud in 60-90 seconds. Model answers are examples, not scripts to memorize.

## 1. Explain the idea in plain English, then connect it to code.

**Model answer:** Translate an existing interface into the contract a client expects. A travel adapter connects an existing plug to the socket you need. In this exercise: The application supplies exact USD cents; the adapter forwards those cents and the USD currency code once. Translate charge(cents) to makePayment("USD", cents). Preserve units and return the provider reference.

**What to demonstrate:** Explain the collaboration before naming classes.

## 2. Where should vendor error codes become application errors?

**Model answer:** At the adapter boundary, preserving the meaning needed by the application.

**What to demonstrate:** Give a concrete example that makes the distinction clear.

## 3. What nearby idea is easy to confuse with this one?

**Model answer:** Adapter reconciles a mismatch. Bridge deliberately separates two dimensions of variation; Decorator adds behavior to the same contract.

**What to demonstrate:** Compare intent and behavior, not just similar-looking diagrams.

## 4. Change request: Implement VendorAdapter.charge without converting cents through floating-point arithmetic.

**Model answer:** Translate charge(cents) to makePayment("USD", cents). Preserve units and return the provider reference.

**What to demonstrate:** Name the exact extension point and identify what remains stable.

## 5. Which tests would convince you that the change is correct?

**Model answer:** Record the vendor arguments for 1999 cents. The vendor must receive 1999, not 19 or 199900.

**What to demonstrate:** State inputs, expected outcomes, and the defect each test would expose.

## 6. What would you clarify before implementing this scenario?

**Model answer:** Ask about units, currency, and error meanings. Here the vendor already takes minor units, so no numeric conversion is required.

**What to demonstrate:** Resolve a consequential ambiguity before coding.

## 7. When would you keep the design simpler or choose another approach?

**Model answer:** The interfaces already match and a wrapper would translate nothing. A thin-looking adapter can still hide important semantic mismatches.

**What to demonstrate:** Explain the cost of the abstraction and the condition that justifies it.

## Self-check

Can you clarify the contract, draw the collaboration, identify the change point, write a test, and explain when a simpler approach wins? Use the original 10-point rubric in the root Interview_Approach.md.
