import java.util.*;

// Original small teaching example. Java 17+, no external libraries.
// Run: java Demo.java
// Exercise checks: java Demo.java --exercise
// Run each folder separately; every example intentionally uses the class name Demo.
public class Demo {
    static int checks;
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
    }
    static void throwsType(Class<? extends Throwable> type, Runnable action) {
        try { action.run(); }
        catch (Throwable error) {
            if (!type.isInstance(error)) throw new AssertionError("Expected " + type.getSimpleName() + ", got " + error, error);
            checks++; return;
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }
    interface Gateway { String charge(int cents); }
    static class Vendor {
        int amount, calls; String currency;
        String makePayment(String currency, int minorUnits) {
            this.currency = currency; amount = minorUnits; calls++; return "ref-1";
        }
    }
    record VendorAdapter(Vendor vendor) implements Gateway {
        public String charge(int cents) {
            return vendor.makePayment("USD", cents);
        }
    }

    public static void main(String[] args) {
        Vendor vendor = new Vendor();
        check(vendor.makePayment("USD", 1).equals("ref-1"), "vendor API");
        if (args.length > 0 && args[0].equals("--exercise")) {
            Vendor recording = new Vendor();
            check(new VendorAdapter(recording).charge(1999).equals("ref-1"), "reference preserved");
            check(recording.amount == 1999 && recording.currency.equals("USD") && recording.calls == 1, "units and call count");
        }
        System.out.println("PASS: Adapter (" + checks + " checks)");
    }
}
