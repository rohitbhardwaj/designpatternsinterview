# Adapter - Solution Notes

## The change

Translate charge(cents) to makePayment("USD", cents). Preserve units and return the provider reference.

## Why it works

The application supplies exact USD cents; the adapter forwards those cents and the USD currency code once.

## How the checks expose mistakes

Record the vendor arguments for 1999 cents. The vendor must receive 1999, not 19 or 199900.

## What to say in an interview

I chose this design because an existing provider interface does not match the application contract. The trade-off is: A thin-looking adapter can still hide important semantic mismatches.

## Nearby alternative

Adapter reconciles a mismatch. Bridge deliberately separates two dimensions of variation; Decorator adds behavior to the same contract.

## When to simplify

The interfaces already match and a wrapper would translate nothing.

Read the complete implementation in `java/solution/Demo.java`. Compare the TASK area with the starter and trace the exercise checks.
