# Adapter

Translate an existing interface into the contract a client expects.

**Category:** Structural

## Start here

- **3 minutes:** Read this page or Quick_Review.pdf.
- **10 minutes:** Answer Interview_QA.md aloud before revealing the answers.
- **15 minutes:** Follow Practice.md and run the Java exercise.
- **48 seconds:** Watch Pattern_Video.mp4; the clip is silent and captioned.
- **With AI:** Copy one prompt from AI_Prompts.txt, then verify the result.

## Picture it

A travel adapter connects an existing plug to the socket you need.

## Use it when

An existing provider interface does not match the application contract.

## Keep it simpler when

The interfaces already match and a wrapper would translate nothing.

## Contract

The application supplies exact USD cents; the adapter forwards those cents and the USD currency code once.

## Nearby idea

Adapter reconciles a mismatch. Bridge deliberately separates two dimensions of variation; Decorator adds behavior to the same contract.

## Interview checkpoint

**Question:** Where should vendor error codes become application errors?

**Answer:** At the adapter boundary, preserving the meaning needed by the application.

## Try it

Implement VendorAdapter.charge without converting cents through floating-point arithmetic.

## Evidence

Record the vendor arguments for 1999 cents. The vendor must receive 1999, not 19 or 199900.

## Trade-off

A thin-looking adapter can still hide important semantic mismatches.

## Scope

The Java exercise is a small, single-process teaching example. Its scenario can differ from the video to help you recognize the same idea in another setting.

[Open the complete visual guide](README.html) | [Interview questions](Interview_QA.md) | [Practice](Practice.md) | [Solution notes](Solution_Notes.md)
