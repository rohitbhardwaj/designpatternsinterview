# Open–Closed

Extend a stable policy through a deliberate variation point.

**Category:** SOLID

## Start here

- **3 minutes:** Read this page or Quick_Review.pdf.
- **10 minutes:** Answer Interview_QA.md aloud before revealing the answers.
- **15 minutes:** Follow Practice.md and run the Java exercise.
- **48 seconds:** Watch Pattern_Video.mp4; the clip is silent and captioned.
- **With AI:** Copy one prompt from AI_Prompts.txt, then verify the result.

## Picture it

A power strip accepts another compatible plug without rewiring the house.

## Use it when

A known policy, such as a discount algorithm, needs independently added variants.

## Keep it simpler when

There are only a few stable cases and no evidence that extensions are needed.

## Contract

Checkout must use the supplied policy; a new policy must not require a new branch in Checkout.

## Nearby idea

OCP is a design goal. Strategy is one way to provide its deliberate extension point; registration may still change.

## Interview checkpoint

**Question:** Must every file remain untouched when a variant is added?

**Answer:** No. Registration or wiring can change while stable policy stays intact.

## Try it

Add a StudentDiscount implementation that subtracts 200 cents without returning a negative total.

## Evidence

Check 1000 becomes 800 and 100 becomes 0. Also run the original no-discount policy unchanged.

## Trade-off

Speculative plug-in systems add cost before variation is real.

## Scope

The Java exercise is a small, single-process teaching example. Its scenario can differ from the video to help you recognize the same idea in another setting.

[Open the complete visual guide](README.html) | [Interview questions](Interview_QA.md) | [Practice](Practice.md) | [Solution notes](Solution_Notes.md)
