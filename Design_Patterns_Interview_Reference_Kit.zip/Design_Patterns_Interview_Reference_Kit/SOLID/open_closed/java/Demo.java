import java.util.*;

// Original small teaching example. Java 17+, no external libraries.
// Run: java Demo.java
// Exercise checks: java Demo.java --exercise
// Run each folder separately; every example intentionally uses the class name Demo.
public class Demo {
    static int checks;
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
    }
    static void throwsType(Class<? extends Throwable> type, Runnable action) {
        try { action.run(); }
        catch (Throwable error) {
            if (!type.isInstance(error)) throw new AssertionError("Expected " + type.getSimpleName() + ", got " + error, error);
            checks++; return;
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }
    interface Discount { int apply(int cents); }
    record Checkout(Discount discount) { int total(int cents) { return discount.apply(cents); } }
    static class StudentDiscount implements Discount {
        public int apply(int cents) {
            throw new UnsupportedOperationException("Implement StudentDiscount");
        }
    }

    public static void main(String[] args) {
        check(new Checkout(x -> x).total(1000) == 1000, "existing policy");
        if (args.length > 0 && args[0].equals("--exercise")) {
            Checkout student = new Checkout(new StudentDiscount());
            check(student.total(1000) == 800, "new policy");
            check(student.total(100) == 0, "minimum total");
        }
        System.out.println("PASS: Open-Closed (" + checks + " checks)");
    }
}
