# Open–Closed - Solution Notes

## The change

Implement the Discount contract and inject it into the existing Checkout. Clamp the result at zero.

## Why it works

Checkout must use the supplied policy; a new policy must not require a new branch in Checkout.

## How the checks expose mistakes

Check 1000 becomes 800 and 100 becomes 0. Also run the original no-discount policy unchanged.

## What to say in an interview

I chose this design because a known policy, such as a discount algorithm, needs independently added variants. The trade-off is: Speculative plug-in systems add cost before variation is real.

## Nearby alternative

OCP is a design goal. Strategy is one way to provide its deliberate extension point; registration may still change.

## When to simplify

There are only a few stable cases and no evidence that extensions are needed.

Read the complete implementation in `java/solution/Demo.java`. Compare the TASK area with the starter and trace the exercise checks.
