# Open–Closed - Interview Questions and Answers

These are original practice questions aligned with skills in published employer guidance. They are not attributed to an actual company interview, endorsed by an employer, or a prediction of interview frequency. See INTERVIEW_GUIDANCE.md at the kit root.

Try each answer aloud in 60-90 seconds. Model answers are examples, not scripts to memorize.

## 1. Explain the idea in plain English, then connect it to code.

**Model answer:** Extend a stable policy through a deliberate variation point. A power strip accepts another compatible plug without rewiring the house. In this exercise: Checkout must use the supplied policy; a new policy must not require a new branch in Checkout. Implement the Discount contract and inject it into the existing Checkout. Clamp the result at zero.

**What to demonstrate:** Explain the collaboration before naming classes.

## 2. Must every file remain untouched when a variant is added?

**Model answer:** No. Registration or wiring can change while stable policy stays intact.

**What to demonstrate:** Give a concrete example that makes the distinction clear.

## 3. What nearby idea is easy to confuse with this one?

**Model answer:** OCP is a design goal. Strategy is one way to provide its deliberate extension point; registration may still change.

**What to demonstrate:** Compare intent and behavior, not just similar-looking diagrams.

## 4. Change request: Add a StudentDiscount implementation that subtracts 200 cents without returning a negative total.

**Model answer:** Implement the Discount contract and inject it into the existing Checkout. Clamp the result at zero.

**What to demonstrate:** Name the exact extension point and identify what remains stable.

## 5. Which tests would convince you that the change is correct?

**Model answer:** Check 1000 becomes 800 and 100 becomes 0. Also run the original no-discount policy unchanged.

**What to demonstrate:** State inputs, expected outcomes, and the defect each test would expose.

## 6. What would you clarify before implementing this scenario?

**Model answer:** Ask whether discounts stack and whether totals can become negative. In this exercise there is one policy and the minimum is zero.

**What to demonstrate:** Resolve a consequential ambiguity before coding.

## 7. When would you keep the design simpler or choose another approach?

**Model answer:** There are only a few stable cases and no evidence that extensions are needed. Speculative plug-in systems add cost before variation is real.

**What to demonstrate:** Explain the cost of the abstraction and the condition that justifies it.

## Self-check

Can you clarify the contract, draw the collaboration, identify the change point, write a test, and explain when a simpler approach wins? Use the original 10-point rubric in the root Interview_Approach.md.
