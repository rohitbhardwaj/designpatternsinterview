# Liskov Substitution - Solution Notes

## The change

Store one validated side and implement area. Keep shape-specific mutation outside the shared contract.

## Why it works

Every Shape returns a nonnegative area for nonnegative dimensions; constructors reject negative dimensions.

## How the checks expose mistakes

Run the same nonnegative-area check for Rectangle and Square, check a known area, and reject a negative side.

## What to say in an interview

I chose this design because several implementations promise the same observable behavior. The trade-off is: An abstraction that promises too much forces invalid implementations.

## Nearby alternative

LSP checks behavior promised by a contract. Inheritance or matching method names alone does not prove it.

## When to simplify

The proposed shared abstraction requires one implementation to reject valid uses of another.

Read the complete implementation in `java/solution/Demo.java`. Compare the TASK area with the starter and trace the exercise checks.
