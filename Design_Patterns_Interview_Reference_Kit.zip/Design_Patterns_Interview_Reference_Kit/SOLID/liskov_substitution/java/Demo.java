import java.util.*;

// Original small teaching example. Java 17+, no external libraries.
// Run: java Demo.java
// Exercise checks: java Demo.java --exercise
// Run each folder separately; every example intentionally uses the class name Demo.
public class Demo {
    static int checks;
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
    }
    static void throwsType(Class<? extends Throwable> type, Runnable action) {
        try { action.run(); }
        catch (Throwable error) {
            if (!type.isInstance(error)) throw new AssertionError("Expected " + type.getSimpleName() + ", got " + error, error);
            checks++; return;
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }
    interface Shape { long area(); }
    record Rectangle(int width, int height) implements Shape {
        Rectangle { if (width < 0 || height < 0) throw new IllegalArgumentException("negative dimension"); }
        public long area() { return (long) width * height; }
    }
    static Shape square(int side) {
        throw new UnsupportedOperationException("Implement square");
    }
    static void shapeContract(Shape shape) { check(shape.area() >= 0, "nonnegative area"); }

    public static void main(String[] args) {
        shapeContract(new Rectangle(5, 4));
        check(new Rectangle(5, 4).area() == 20, "rectangle area");
        if (args.length > 0 && args[0].equals("--exercise")) {
            shapeContract(square(5));
            shapeContract(square(0));
            check(square(5).area() == 25, "square area");
            throwsType(IllegalArgumentException.class, () -> square(-1));
        }
        System.out.println("PASS: Liskov Substitution (" + checks + " checks)");
    }
}
