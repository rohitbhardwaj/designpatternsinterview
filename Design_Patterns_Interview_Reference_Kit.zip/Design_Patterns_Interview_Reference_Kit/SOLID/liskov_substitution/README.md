# Liskov Substitution

Every implementation must honor its advertised contract.

**Category:** SOLID

## Start here

- **3 minutes:** Read this page or Quick_Review.pdf.
- **10 minutes:** Answer Interview_QA.md aloud before revealing the answers.
- **15 minutes:** Follow Practice.md and run the Java exercise.
- **48 seconds:** Watch Pattern_Video.mp4; the clip is silent and captioned.
- **With AI:** Copy one prompt from AI_Prompts.txt, then verify the result.

## Picture it

A replacement charger must honor the promised voltage, not merely fit the socket.

## Use it when

Several implementations promise the same observable behavior.

## Keep it simpler when

The proposed shared abstraction requires one implementation to reject valid uses of another.

## Contract

Every Shape returns a nonnegative area for nonnegative dimensions; constructors reject negative dimensions.

## Nearby idea

LSP checks behavior promised by a contract. Inheritance or matching method names alone does not prove it.

## Interview checkpoint

**Question:** Does declaring a class final prove LSP?

**Answer:** No. Final blocks subclassing; LSP concerns the behavior promised by an abstraction.

## Try it

Implement Square so it satisfies the Shape contract without exposing independent width and height setters.

## Evidence

Run the same nonnegative-area check for Rectangle and Square, check a known area, and reject a negative side.

## Trade-off

An abstraction that promises too much forces invalid implementations.

## Scope

The Java exercise is a small, single-process teaching example. Its scenario can differ from the video to help you recognize the same idea in another setting.

[Open the complete visual guide](README.html) | [Interview questions](Interview_QA.md) | [Practice](Practice.md) | [Solution notes](Solution_Notes.md)
