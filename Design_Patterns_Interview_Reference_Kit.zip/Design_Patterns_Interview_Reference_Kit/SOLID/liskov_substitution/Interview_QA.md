# Liskov Substitution - Interview Questions and Answers

These are original practice questions aligned with skills in published employer guidance. They are not attributed to an actual company interview, endorsed by an employer, or a prediction of interview frequency. See INTERVIEW_GUIDANCE.md at the kit root.

Try each answer aloud in 60-90 seconds. Model answers are examples, not scripts to memorize.

## 1. Explain the idea in plain English, then connect it to code.

**Model answer:** Every implementation must honor its advertised contract. A replacement charger must honor the promised voltage, not merely fit the socket. In this exercise: Every Shape returns a nonnegative area for nonnegative dimensions; constructors reject negative dimensions. Store one validated side and implement area. Keep shape-specific mutation outside the shared contract.

**What to demonstrate:** Explain the collaboration before naming classes.

## 2. Does declaring a class final prove LSP?

**Model answer:** No. Final blocks subclassing; LSP concerns the behavior promised by an abstraction.

**What to demonstrate:** Give a concrete example that makes the distinction clear.

## 3. What nearby idea is easy to confuse with this one?

**Model answer:** LSP checks behavior promised by a contract. Inheritance or matching method names alone does not prove it.

**What to demonstrate:** Compare intent and behavior, not just similar-looking diagrams.

## 4. Change request: Implement Square so it satisfies the Shape contract without exposing independent width and height setters.

**Model answer:** Store one validated side and implement area. Keep shape-specific mutation outside the shared contract.

**What to demonstrate:** Name the exact extension point and identify what remains stable.

## 5. Which tests would convince you that the change is correct?

**Model answer:** Run the same nonnegative-area check for Rectangle and Square, check a known area, and reject a negative side.

**What to demonstrate:** State inputs, expected outcomes, and the defect each test would expose.

## 6. What would you clarify before implementing this scenario?

**Model answer:** Ask whether dimensions are mutable. Here shapes are immutable and only area is shared; independent setters are not promised.

**What to demonstrate:** Resolve a consequential ambiguity before coding.

## 7. When would you keep the design simpler or choose another approach?

**Model answer:** The proposed shared abstraction requires one implementation to reject valid uses of another. An abstraction that promises too much forces invalid implementations.

**What to demonstrate:** Explain the cost of the abstraction and the condition that justifies it.

## Self-check

Can you clarify the contract, draw the collaboration, identify the change point, write a test, and explain when a simpler approach wins? Use the original 10-point rubric in the root Interview_Approach.md.
