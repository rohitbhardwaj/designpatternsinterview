import java.util.*;

// Original small teaching example. Java 17+, no external libraries.
// Run: java Demo.java
// Exercise checks: java Demo.java --exercise
// Run each folder separately; every example intentionally uses the class name Demo.
public class Demo {
    static int checks;
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
    }
    static void throwsType(Class<? extends Throwable> type, Runnable action) {
        try { action.run(); }
        catch (Throwable error) {
            if (!type.isInstance(error)) throw new AssertionError("Expected " + type.getSimpleName() + ", got " + error, error);
            checks++; return;
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }
    interface TaxPolicy { int total(int subtotal); }
    static String formatReceipt(int total) { return "Total=" + total; }
    static int totalWithTax(int subtotal, TaxPolicy policy) {
        // TASK: delegate to the policy without changing formatReceipt.
        throw new UnsupportedOperationException("Implement totalWithTax");
    }

    public static void main(String[] args) {
        check(formatReceipt(1100).equals("Total=1100"), "receipt formatting");
        if (args.length > 0 && args[0].equals("--exercise")) {
            check(totalWithTax(1000, x -> x + 100) == 1100, "flat tax");
            check(totalWithTax(1000, x -> x) == 1000, "tax exempt");
            check(formatReceipt(totalWithTax(1000, x -> x + 50)).equals("Total=1050"), "composition");
        }
        System.out.println("PASS: Single Responsibility (" + checks + " checks)");
    }
}
