# Single Responsibility

Separate code that changes for different reasons.

**Category:** SOLID

## Start here

- **3 minutes:** Read this page or Quick_Review.pdf.
- **10 minutes:** Answer Interview_QA.md aloud before revealing the answers.
- **15 minutes:** Follow Practice.md and run the Java exercise.
- **48 seconds:** Watch Pattern_Video.mp4; the clip is silent and captioned.
- **With AI:** Copy one prompt from AI_Prompts.txt, then verify the result.

## Picture it

A restaurant separates cooking, billing, and delivery, even though one order connects them.

## Use it when

Pricing rules, storage, and delivery change for different business reasons.

## Keep it simpler when

A small cohesive calculation has no independent reason to be split.

## Contract

Changing tax calculation must not change how receipts are formatted or recorded.

## Nearby idea

SRP groups code by reasons to change. Interface Segregation limits what a particular client must depend on.

## Interview checkpoint

**Question:** Does calling three collaborators automatically violate SRP?

**Answer:** No. Coordinating one use case can be a cohesive responsibility.

## Try it

Complete totalWithTax so a new tax policy can be supplied without changing receipt formatting.

## Evidence

Use two policies on the same subtotal, then verify the receipt uses the returned total. This exposes a hard-coded tax rate.

## Trade-off

Excessive splitting increases navigation and coordination cost.

## Scope

The Java exercise is a small, single-process teaching example. Its scenario can differ from the video to help you recognize the same idea in another setting.

[Open the complete visual guide](README.html) | [Interview questions](Interview_QA.md) | [Practice](Practice.md) | [Solution notes](Solution_Notes.md)
