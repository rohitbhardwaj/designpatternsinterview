# Single Responsibility - Solution Notes

## The change

Delegate the calculation to TaxPolicy. Keep formatReceipt focused on presentation; the caller wires the policy.

## Why it works

Changing tax calculation must not change how receipts are formatted or recorded.

## How the checks expose mistakes

Use two policies on the same subtotal, then verify the receipt uses the returned total. This exposes a hard-coded tax rate.

## What to say in an interview

I chose this design because pricing rules, storage, and delivery change for different business reasons. The trade-off is: Excessive splitting increases navigation and coordination cost.

## Nearby alternative

SRP groups code by reasons to change. Interface Segregation limits what a particular client must depend on.

## When to simplify

A small cohesive calculation has no independent reason to be split.

Read the complete implementation in `java/solution/Demo.java`. Compare the TASK area with the starter and trace the exercise checks.
