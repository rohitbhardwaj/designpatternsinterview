# Single Responsibility - Interview Questions and Answers

These are original practice questions aligned with skills in published employer guidance. They are not attributed to an actual company interview, endorsed by an employer, or a prediction of interview frequency. See INTERVIEW_GUIDANCE.md at the kit root.

Try each answer aloud in 60-90 seconds. Model answers are examples, not scripts to memorize.

## 1. Explain the idea in plain English, then connect it to code.

**Model answer:** Separate code that changes for different reasons. A restaurant separates cooking, billing, and delivery, even though one order connects them. In this exercise: Changing tax calculation must not change how receipts are formatted or recorded. Delegate the calculation to TaxPolicy. Keep formatReceipt focused on presentation; the caller wires the policy.

**What to demonstrate:** Explain the collaboration before naming classes.

## 2. Does calling three collaborators automatically violate SRP?

**Model answer:** No. Coordinating one use case can be a cohesive responsibility.

**What to demonstrate:** Give a concrete example that makes the distinction clear.

## 3. What nearby idea is easy to confuse with this one?

**Model answer:** SRP groups code by reasons to change. Interface Segregation limits what a particular client must depend on.

**What to demonstrate:** Compare intent and behavior, not just similar-looking diagrams.

## 4. Change request: Complete totalWithTax so a new tax policy can be supplied without changing receipt formatting.

**Model answer:** Delegate the calculation to TaxPolicy. Keep formatReceipt focused on presentation; the caller wires the policy.

**What to demonstrate:** Name the exact extension point and identify what remains stable.

## 5. Which tests would convince you that the change is correct?

**Model answer:** Use two policies on the same subtotal, then verify the receipt uses the returned total. This exposes a hard-coded tax rate.

**What to demonstrate:** State inputs, expected outcomes, and the defect each test would expose.

## 6. What would you clarify before implementing this scenario?

**Model answer:** Ask who owns tax rules and receipt formatting, and whether they change independently. Here they do; amounts are integer cents.

**What to demonstrate:** Resolve a consequential ambiguity before coding.

## 7. When would you keep the design simpler or choose another approach?

**Model answer:** A small cohesive calculation has no independent reason to be split. Excessive splitting increases navigation and coordination cost.

**What to demonstrate:** Explain the cost of the abstraction and the condition that justifies it.

## Self-check

Can you clarify the contract, draw the collaboration, identify the change point, write a test, and explain when a simpler approach wins? Use the original 10-point rubric in the root Interview_Approach.md.
