# Interface Segregation - Interview Questions and Answers

These are original practice questions aligned with skills in published employer guidance. They are not attributed to an actual company interview, endorsed by an employer, or a prediction of interview frequency. See INTERVIEW_GUIDANCE.md at the kit root.

Try each answer aloud in 60-90 seconds. Model answers are examples, not scripts to memorize.

## 1. Explain the idea in plain English, then connect it to code.

**Model answer:** Each client depends on the capabilities it actually needs. A TV remote offers viewing controls; it does not require you to operate the repair tools. In this exercise: A print queue accepts any Printable and never requires scan support. Accept Printable, call print, and leave Scannable out of the print queue dependency.

**What to demonstrate:** Explain the collaboration before naming classes.

## 2. Can one concrete class implement several small interfaces?

**Model answer:** Yes. Clients can each depend on the capability they need.

**What to demonstrate:** Give a concrete example that makes the distinction clear.

## 3. What nearby idea is easy to confuse with this one?

**Model answer:** ISP asks what a client needs. SRP asks why implementation code changes. A class can implement several focused interfaces.

**What to demonstrate:** Compare intent and behavior, not just similar-looking diagrams.

## 4. Change request: Implement printJob against Printable so both a basic printer and a copier can be used.

**Model answer:** Accept Printable, call print, and leave Scannable out of the print queue dependency.

**What to demonstrate:** Name the exact extension point and identify what remains stable.

## 5. Which tests would convince you that the change is correct?

**Model answer:** Pass a lambda that only implements printing, then a copier that implements both capabilities.

**What to demonstrate:** State inputs, expected outcomes, and the defect each test would expose.

## 6. What would you clarify before implementing this scenario?

**Model answer:** Ask which operations the print queue actually needs. It needs print only; scanning is a separate client capability.

**What to demonstrate:** Resolve a consequential ambiguity before coding.

## 7. When would you keep the design simpler or choose another approach?

**Model answer:** The same clients always need all the operations together. Tiny interfaces with no meaningful client boundary become clutter.

**What to demonstrate:** Explain the cost of the abstraction and the condition that justifies it.

## Self-check

Can you clarify the contract, draw the collaboration, identify the change point, write a test, and explain when a simpler approach wins? Use the original 10-point rubric in the root Interview_Approach.md.
