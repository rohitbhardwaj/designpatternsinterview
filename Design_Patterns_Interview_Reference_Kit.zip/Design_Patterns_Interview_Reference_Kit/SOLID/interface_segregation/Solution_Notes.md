# Interface Segregation - Solution Notes

## The change

Accept Printable, call print, and leave Scannable out of the print queue dependency.

## Why it works

A print queue accepts any Printable and never requires scan support.

## How the checks expose mistakes

Pass a lambda that only implements printing, then a copier that implements both capabilities.

## What to say in an interview

I chose this design because different clients use different capabilities of the same object. The trade-off is: Tiny interfaces with no meaningful client boundary become clutter.

## Nearby alternative

ISP asks what a client needs. SRP asks why implementation code changes. A class can implement several focused interfaces.

## When to simplify

The same clients always need all the operations together.

Read the complete implementation in `java/solution/Demo.java`. Compare the TASK area with the starter and trace the exercise checks.
