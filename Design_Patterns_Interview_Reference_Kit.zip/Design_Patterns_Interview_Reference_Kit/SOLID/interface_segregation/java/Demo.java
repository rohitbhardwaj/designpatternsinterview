import java.util.*;

// Original small teaching example. Java 17+, no external libraries.
// Run: java Demo.java
// Exercise checks: java Demo.java --exercise
// Run each folder separately; every example intentionally uses the class name Demo.
public class Demo {
    static int checks;
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
    }
    static void throwsType(Class<? extends Throwable> type, Runnable action) {
        try { action.run(); }
        catch (Throwable error) {
            if (!type.isInstance(error)) throw new AssertionError("Expected " + type.getSimpleName() + ", got " + error, error);
            checks++; return;
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }
    interface Printable { String print(); }
    interface Scannable { String scan(); }
    static class Copier implements Printable, Scannable {
        public String print() { return "copier print"; }
        public String scan() { return "scan"; }
    }
    static String printJob(Printable device) {
        throw new UnsupportedOperationException("Implement printJob");
    }

    public static void main(String[] args) {
        check(new Copier().scan().equals("scan"), "independent scan capability");
        if (args.length > 0 && args[0].equals("--exercise")) {
            check(printJob(() -> "basic print").equals("basic print"), "print-only device");
            check(printJob(new Copier()).equals("copier print"), "multi-capability device");
        }
        System.out.println("PASS: Interface Segregation (" + checks + " checks)");
    }
}
