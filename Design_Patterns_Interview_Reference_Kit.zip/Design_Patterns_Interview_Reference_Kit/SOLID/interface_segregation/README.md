# Interface Segregation

Each client depends on the capabilities it actually needs.

**Category:** SOLID

## Start here

- **3 minutes:** Read this page or Quick_Review.pdf.
- **10 minutes:** Answer Interview_QA.md aloud before revealing the answers.
- **15 minutes:** Follow Practice.md and run the Java exercise.
- **48 seconds:** Watch Pattern_Video.mp4; the clip is silent and captioned.
- **With AI:** Copy one prompt from AI_Prompts.txt, then verify the result.

## Picture it

A TV remote offers viewing controls; it does not require you to operate the repair tools.

## Use it when

Different clients use different capabilities of the same object.

## Keep it simpler when

The same clients always need all the operations together.

## Contract

A print queue accepts any Printable and never requires scan support.

## Nearby idea

ISP asks what a client needs. SRP asks why implementation code changes. A class can implement several focused interfaces.

## Interview checkpoint

**Question:** Can one concrete class implement several small interfaces?

**Answer:** Yes. Clients can each depend on the capability they need.

## Try it

Implement printJob against Printable so both a basic printer and a copier can be used.

## Evidence

Pass a lambda that only implements printing, then a copier that implements both capabilities.

## Trade-off

Tiny interfaces with no meaningful client boundary become clutter.

## Scope

The Java exercise is a small, single-process teaching example. Its scenario can differ from the video to help you recognize the same idea in another setting.

[Open the complete visual guide](README.html) | [Interview questions](Interview_QA.md) | [Practice](Practice.md) | [Solution notes](Solution_Notes.md)
