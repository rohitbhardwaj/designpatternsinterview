# Dependency Inversion - Solution Notes

## The change

Call the application-owned port. Construct real vendor adapters at startup, outside Checkout.

## Why it works

Checkout depends only on PaymentGateway and forwards the exact amount once.

## How the checks expose mistakes

Record amount and call count in the fake; verify 1200 cents and exactly one invocation.

## What to say in an interview

I chose this design because business policy needs infrastructure that should be replaceable and testable. The trade-off is: An interface that merely mirrors a vendor SDK may preserve vendor coupling.

## Nearby alternative

Dependency injection supplies dependencies. DIP makes policy depend on a suitable abstraction; injecting a concrete SDK is insufficient.

## When to simplify

An interface simply copies a vendor SDK and leaves its types spread through the use case.

Read the complete implementation in `java/solution/Demo.java`. Compare the TASK area with the starter and trace the exercise checks.
