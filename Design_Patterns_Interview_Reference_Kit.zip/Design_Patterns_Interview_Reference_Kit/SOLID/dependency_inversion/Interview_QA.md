# Dependency Inversion - Interview Questions and Answers

These are original practice questions aligned with skills in published employer guidance. They are not attributed to an actual company interview, endorsed by an employer, or a prediction of interview frequency. See INTERVIEW_GUIDANCE.md at the kit root.

Try each answer aloud in 60-90 seconds. Model answers are examples, not scripts to memorize.

## 1. Explain the idea in plain English, then connect it to code.

**Model answer:** Policy owns a contract that infrastructure implements. A wall outlet defines a shared contract; appliances adapt to it rather than rewiring your home. In this exercise: Checkout depends only on PaymentGateway and forwards the exact amount once. Call the application-owned port. Construct real vendor adapters at startup, outside Checkout.

**What to demonstrate:** Explain the collaboration before naming classes.

## 2. Is constructor injection alone enough to establish DIP?

**Model answer:** No. Injecting a concrete vendor client can leave policy coupled to infrastructure.

**What to demonstrate:** Give a concrete example that makes the distinction clear.

## 3. What nearby idea is easy to confuse with this one?

**Model answer:** Dependency injection supplies dependencies. DIP makes policy depend on a suitable abstraction; injecting a concrete SDK is insufficient.

**What to demonstrate:** Compare intent and behavior, not just similar-looking diagrams.

## 4. Change request: Implement Checkout.pay using the injected PaymentGateway. Test with a recording fake.

**Model answer:** Call the application-owned port. Construct real vendor adapters at startup, outside Checkout.

**What to demonstrate:** Name the exact extension point and identify what remains stable.

## 5. Which tests would convince you that the change is correct?

**Model answer:** Record amount and call count in the fake; verify 1200 cents and exactly one invocation.

**What to demonstrate:** State inputs, expected outcomes, and the defect each test would expose.

## 6. What would you clarify before implementing this scenario?

**Model answer:** Ask what the application payment result means. Here pay returns an authorization reference; no network call is needed in the exercise.

**What to demonstrate:** Resolve a consequential ambiguity before coding.

## 7. When would you keep the design simpler or choose another approach?

**Model answer:** An interface simply copies a vendor SDK and leaves its types spread through the use case. An interface that merely mirrors a vendor SDK may preserve vendor coupling.

**What to demonstrate:** Explain the cost of the abstraction and the condition that justifies it.

## Self-check

Can you clarify the contract, draw the collaboration, identify the change point, write a test, and explain when a simpler approach wins? Use the original 10-point rubric in the root Interview_Approach.md.
