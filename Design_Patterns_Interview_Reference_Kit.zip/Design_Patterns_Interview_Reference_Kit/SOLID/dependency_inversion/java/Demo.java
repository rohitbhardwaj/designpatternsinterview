import java.util.*;

// Original small teaching example. Java 17+, no external libraries.
// Run: java Demo.java
// Exercise checks: java Demo.java --exercise
// Run each folder separately; every example intentionally uses the class name Demo.
public class Demo {
    static int checks;
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
    }
    static void throwsType(Class<? extends Throwable> type, Runnable action) {
        try { action.run(); }
        catch (Throwable error) {
            if (!type.isInstance(error)) throw new AssertionError("Expected " + type.getSimpleName() + ", got " + error, error);
            checks++; return;
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }
    interface PaymentGateway { String pay(int cents); }
    record Checkout(PaymentGateway gateway) {
        String pay(int cents) {
            throw new UnsupportedOperationException("Implement Checkout.pay");
        }
    }
    static class FakeGateway implements PaymentGateway {
        int calls, amount;
        public String pay(int cents) { calls++; amount = cents; return "approved"; }
    }

    public static void main(String[] args) {
        FakeGateway fake = new FakeGateway();
        check(fake.pay(10).equals("approved") && fake.calls == 1, "fake contract");
        if (args.length > 0 && args[0].equals("--exercise")) {
            FakeGateway recording = new FakeGateway();
            check(new Checkout(recording).pay(1200).equals("approved"), "result forwarded");
            check(recording.calls == 1 && recording.amount == 1200, "one exact call");
        }
        System.out.println("PASS: Dependency Inversion (" + checks + " checks)");
    }
}
