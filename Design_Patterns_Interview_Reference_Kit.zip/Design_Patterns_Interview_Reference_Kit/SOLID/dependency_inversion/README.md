# Dependency Inversion

Policy owns a contract that infrastructure implements.

**Category:** SOLID

## Start here

- **3 minutes:** Read this page or Quick_Review.pdf.
- **10 minutes:** Answer Interview_QA.md aloud before revealing the answers.
- **15 minutes:** Follow Practice.md and run the Java exercise.
- **48 seconds:** Watch Pattern_Video.mp4; the clip is silent and captioned.
- **With AI:** Copy one prompt from AI_Prompts.txt, then verify the result.

## Picture it

A wall outlet defines a shared contract; appliances adapt to it rather than rewiring your home.

## Use it when

Business policy needs infrastructure that should be replaceable and testable.

## Keep it simpler when

An interface simply copies a vendor SDK and leaves its types spread through the use case.

## Contract

Checkout depends only on PaymentGateway and forwards the exact amount once.

## Nearby idea

Dependency injection supplies dependencies. DIP makes policy depend on a suitable abstraction; injecting a concrete SDK is insufficient.

## Interview checkpoint

**Question:** Is constructor injection alone enough to establish DIP?

**Answer:** No. Injecting a concrete vendor client can leave policy coupled to infrastructure.

## Try it

Implement Checkout.pay using the injected PaymentGateway. Test with a recording fake.

## Evidence

Record amount and call count in the fake; verify 1200 cents and exactly one invocation.

## Trade-off

An interface that merely mirrors a vendor SDK may preserve vendor coupling.

## Scope

The Java exercise is a small, single-process teaching example. Its scenario can differ from the video to help you recognize the same idea in another setting.

[Open the complete visual guide](README.html) | [Interview questions](Interview_QA.md) | [Practice](Practice.md) | [Solution notes](Solution_Notes.md)
