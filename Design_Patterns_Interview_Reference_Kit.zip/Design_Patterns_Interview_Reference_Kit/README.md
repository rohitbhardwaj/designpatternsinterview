# Design Patterns Interview Reference Kit

Prepared for Rohit Bhardwaj's workshop.

## Open this first

Extract the ZIP fully, then double-click **START_HERE.html**. It opens an offline topic index in a browser. Choose a pattern and use its review, interview, practice, and AI-prompt sections. Internet access is unnecessary for the guide and videos; source links are external.

If your previewer does not open local links, use the extracted files on your computer. Each pattern also has a printable PDF and plain-text/Markdown references.

## Coverage

- 5 SOLID principles.
- 5 original GoF creational patterns, plus Simple Factory and Object Pool.
- 7 structural patterns.
- 11 behavioral patterns.

30 topic folders, 210 original practice Q&As, 180 copy-and-paste AI prompts, 30 small Java exercises with solutions, 30 quick cards, and 30 captioned videos.

## Choose your time budget

| Time | Action |
|---|---|
| 3 minutes | Open Quick_Review.pdf or read the top of a topic's guide |
| 48 seconds | Watch Pattern_Video.mp4; it is intentionally silent |
| 10 minutes | Answer the interview questions before reading model answers |
| 15 minutes | Complete Practice.md and run the exercise checks |

The notes are for reference and self-study; the instructor does not need to teach every file live.

## Inside each folder

- README.html: complete visual guide with model answers and copyable prompts.
- README.md: portable quick review.
- Quick_Review.pdf: one-page printable card.
- Interview_QA.md: seven original questions with model answers and assessment cues.
- AI_Prompts.txt: six prompts for learning, rehearsal, implementation, review, testing, and trade-off analysis.
- Practice.md: one small change with run instructions and completion criteria.
- Solution_Notes.md: explanation, tests, and alternatives.
- java/Demo.java: runnable baseline and deliberately failing exercise mode.
- java/solution/Demo.java: complete implementation and exercise checks.
- Pattern_Video.mp4, Captions.srt, Diagram.png, Presenter_Notes.txt: the visual explainer and its supporting material.

## Shared resources

- All_Quick_Review_Cards.pdf: all 30 cards in one printable collection.
- Interview_Approach.md: a short answer method and an original 10-point learning rubric.
- INTERVIEW_GUIDANCE.md: company-guidance alignment, sources, and attribution boundaries.
- Animated_Explainers.pptx: the previously prepared deck with embedded clips and speaker notes. Use desktop PowerPoint for video playback.
- VALIDATION.txt: recorded checks for this delivery.

## Java setup

Use Java 17 or later with source-file execution available. In each pattern's java folder run `java Demo.java`, then `java Demo.java --exercise`. The first should pass. The second deliberately fails until you complete the task. Run `java solution/Demo.java --exercise` to check the supplied solution.

There is no build system and no external dependency. Run one topic at a time because the standalone examples all use the class name Demo. Explicit checks run without enabling Java assertions. These examples are deliberately small and are not production libraries.

## Interview attribution

All questions are original practice material, aligned with publicly described skills from Amazon, Microsoft, and Atlassian and supported formats from HackerRank. They are not claimed to be actual questions asked by those organizations. No employer endorsement or interview-frequency ranking is implied.
