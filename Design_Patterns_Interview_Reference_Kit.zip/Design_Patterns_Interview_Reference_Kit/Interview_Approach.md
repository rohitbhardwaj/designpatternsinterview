# A simple approach to design interviews

Use this as a rehearsal aid, not a memorized speech.

1. **Clarify the contract.** What must the component do? What inputs, results, errors, and state transitions are promised?
2. **Describe the smallest useful design.** Identify responsibilities and show one concrete call flow.
3. **Name the expected change.** Explain which part varies and whether an abstraction earns its cost.
4. **Implement and test.** Show working behavior, an important boundary, and a failure case. A pattern name is not proof.
5. **Defend and adapt.** Explain an alternative, the cost of your choice, and what requirement would change your decision.

## A 60-second answer structure

The problem is ___. The part expected to vary is ___. I would keep ___ stable and put ___ behind this contract. The benefit is ___. The cost is ___. I would prove the behavior with this input and expected result: ___. If the requirement were ___, I would use the simpler alternative ___ instead.

## Original workshop rubric: 10 points

This is a learning rubric created for this kit, not a company's hiring scorecard.

| Area | 0 | 1 | 2 |
|---|---|---|---|
| Requirements and contracts | Important assumptions hidden | Some assumptions stated | Relevant inputs, outputs, errors, and scope explicit |
| Correctness and tests | Happy path unproven | Basic test or partial implementation | Working behavior plus meaningful boundary/failure evidence |
| Proportionate design | Pattern added without a reason | Useful design with unnecessary parts | Smallest design that supports the stated change |
| Adaptation and trade-offs | Cannot explain alternatives | Names a trade-off | Explains impact of a new requirement and when to change approach |
| Communication | Lists classes without a call flow | Reasoning partly visible | Clear decisions, one concrete trace, and precise explanation |

## A 15-minute paired rehearsal

- 2 minutes: clarify the folder's exercise contract.
- 3 minutes: sketch and explain the collaboration.
- 5 minutes: make the exercise change or describe it precisely.
- 3 minutes: run checks and explain what each proves.
- 2 minutes: ask the comparison and simplification questions, then score with evidence.

## A 45-minute mock interview

- 5 minutes: requirements and scope.
- 8 minutes: baseline design and an alternative.
- 15 minutes: implement the small component.
- 7 minutes: tests and failure analysis.
- 7 minutes: introduce one changed requirement from Interview_QA.md.
- 3 minutes: candidate recap and feedback.

For Java examples, trace the interfaces and delegation first. The exercises intentionally avoid frameworks and external services so design reasoning remains visible.
