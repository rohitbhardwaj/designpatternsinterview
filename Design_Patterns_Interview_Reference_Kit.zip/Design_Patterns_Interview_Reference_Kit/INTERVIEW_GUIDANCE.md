# Interview alignment and sources

Reviewed 12 October 2026. This is independent workshop practice material prepared for Rohit Bhardwaj. All questions, answers, Java exercises, and prompts in this kit are original teaching material. The sources below inform the skills practiced; they do not establish that a specific employer asks a particular question in this kit. Interview processes vary by role and team.

## Amazon: working, maintainable, tested code

Amazon's senior engineering preparation guide describes low-level design preparation and emphasizes robust, maintainable, readable code and validation of edge cases. The kit practices small implementations with explicit contracts and checks. Its examples do not reproduce Amazon's interview questions.

https://www.amazon.jobs/content/en/how-we-hire/sde-iii-interview-prep
https://amazon.jobs/content/en/how-we-hire/interview-prep/software-development-topics

## Microsoft: clarify, plan, implement, test

Microsoft's technical interview guidance asks candidates to clarify ambiguity, plan before implementation, write working code, and test their solutions. Each kit exercise includes a clarification prompt, a stated contract, and executable checks.

https://careers.microsoft.com/v2/global/en/hiring-tips/technical-interviewing

## Atlassian: code design and explained trade-offs

Atlassian's engineering handbook identifies code design within its coding interviews and emphasizes thought process and trade-offs. Its system-design section describes follow-up questions that can introduce new constraints. The kit uses comparison questions, small change requests, and explanation of alternatives to rehearse these skills.

https://www.atlassian.com/company/careers/resources/interviewing/engineering

## HackerRank: practice formats

HackerRank documents support for coding, code-repository, and code-review questions in interviews. The kit's runnable exercises and AI review prompts rehearse those types of activities. Platform support is not evidence that every employer uses a given format or permits AI during an interview. Use AI for preparation; follow the actual interviewer's rules during an assessment.

https://support.hackerrank.com/articles/2354192461-question-types-in-hackerrank-tests

## Pattern foundations and workshop context

The original Gang of Four catalog contains 23 patterns: five creational, seven structural, and eleven behavioral. This kit adds Simple Factory and Object Pool as additional creation topics and includes the five SOLID principles. It keeps those categories distinct.

Gamma, Helm, Johnson, Vlissides: Design Patterns: Elements of Reusable Object-Oriented Software.
https://www.informit.com/store/design-patterns-elements-of-reusable-object-oriented-9780201633610

Robert C. Martin on Single Responsibility:
https://blog.cleancoder.com/uncle-bob/2014/05/08/SingleReponsibilityPrinciple.html

User-supplied workshop repository:
https://github.com/rohitbhardwaj/designpatternsinterview

The kit's Java files are new standalone teaching examples; they do not modify or depend on that repository. Visual explainers are the 30 clips prepared earlier for this workshop. A Java exercise sometimes uses a different scenario to test transfer of the same concept.
